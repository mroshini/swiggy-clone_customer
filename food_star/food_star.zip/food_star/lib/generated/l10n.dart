// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

class S {
  S();
  
  static const AppLocalizationDelegate delegate =
    AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false) ? locale.languageCode : locale.toString();
    final localeName = Intl.canonicalizedLocale(name); 
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      return S();
    });
  } 

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  String get order {
    return Intl.message(
      'Order',
      name: 'order',
      desc: '',
      args: [],
    );
  }

  String get yourLocation {
    return Intl.message(
      'Your Location',
      name: 'yourLocation',
      desc: '',
      args: [],
    );
  }

  String get changePassword {
    return Intl.message(
      'Change Password',
      name: 'changePassword',
      desc: '',
      args: [],
    );
  }

  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  String get continue_button_text {
    return Intl.message(
      'CONTINUE',
      name: 'continue_button_text',
      desc: '',
      args: [],
    );
  }

  String get forgotPassword {
    return Intl.message(
      'Forgot Password',
      name: 'forgotPassword',
      desc: '',
      args: [],
    );
  }

  String get enterRegisteredPhoneNumberOrEmail {
    return Intl.message(
      'Enter registered phone number or email',
      name: 'enterRegisteredPhoneNumberOrEmail',
      desc: '',
      args: [],
    );
  }

  String get phoneNumberOrEmail {
    return Intl.message(
      'Phone Number or Email',
      name: 'phoneNumberOrEmail',
      desc: '',
      args: [],
    );
  }

  String get pleaseEnterYourPhoneNumber {
    return Intl.message(
      'Please enter your phone number',
      name: 'pleaseEnterYourPhoneNumber',
      desc: '',
      args: [],
    );
  }

  String get loginMobileNumber {
    return Intl.message(
      'Login Mobile Number',
      name: 'loginMobileNumber',
      desc: '',
      args: [],
    );
  }

  String get enterOtp {
    return Intl.message(
      'Enter OTP',
      name: 'enterOtp',
      desc: '',
      args: [],
    );
  }

  String get resendOtp {
    return Intl.message(
      'Resend OTP',
      name: 'resendOtp',
      desc: '',
      args: [],
    );
  }

  String get timer {
    return Intl.message(
      'Timer',
      name: 'timer',
      desc: '',
      args: [],
    );
  }

  String get weHaveSentAnOtpOn {
    return Intl.message(
      'We\'ve sent an otp on',
      name: 'weHaveSentAnOtpOn',
      desc: '',
      args: [],
    );
  }

  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: '',
      args: [],
    );
  }

  String get pleaseEnterYourPersonalDetailsWorryNotTheyAreSafe {
    return Intl.message(
      'Please enter your personal details. Worry not, they are safe with us',
      name: 'pleaseEnterYourPersonalDetailsWorryNotTheyAreSafe',
      desc: '',
      args: [],
    );
  }

  String get name {
    return Intl.message(
      'Name',
      name: 'name',
      desc: '',
      args: [],
    );
  }

  String get phonenumber {
    return Intl.message(
      'PhoneNumber',
      name: 'phonenumber',
      desc: '',
      args: [],
    );
  }

  String get email {
    return Intl.message(
      'email',
      name: 'email',
      desc: '',
      args: [],
    );
  }

  String get languages {
    return Intl.message(
      'Languages',
      name: 'languages',
      desc: '',
      args: [],
    );
  }

  String get hiEveryone {
    return Intl.message(
      'Hi Everyone',
      name: 'hiEveryone',
      desc: '',
      args: [],
    );
  }

  String get foodstar {
    return Intl.message(
      'FOODSTAR',
      name: 'foodstar',
      desc: '',
      args: [],
    );
  }

  String get search {
    return Intl.message(
      'SEARCH',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  String get cart {
    return Intl.message(
      'CART',
      name: 'cart',
      desc: '',
      args: [],
    );
  }

  String get account {
    return Intl.message(
      'ACCOUNT',
      name: 'account',
      desc: '',
      args: [],
    );
  }

  String get searchRestaurants {
    return Intl.message(
      'Search Restaurants',
      name: 'searchRestaurants',
      desc: '',
      args: [],
    );
  }

  String get clear {
    return Intl.message(
      'Clear',
      name: 'clear',
      desc: '',
      args: [],
    );
  }

  String get recentSearchers {
    return Intl.message(
      'RECENT SEARCHERS',
      name: 'recentSearchers',
      desc: '',
      args: [],
    );
  }

  String get topSearchers {
    return Intl.message(
      'TOP SEARCHERS',
      name: 'topSearchers',
      desc: '',
      args: [],
    );
  }

  String get sortAndFilters {
    return Intl.message(
      'Sort and Filters',
      name: 'sortAndFilters',
      desc: '',
      args: [],
    );
  }

  String get clearAll {
    return Intl.message(
      'Clear All',
      name: 'clearAll',
      desc: '',
      args: [],
    );
  }

  String get apply {
    return Intl.message(
      'Apply',
      name: 'apply',
      desc: '',
      args: [],
    );
  }

  String get addNotesToYourDish {
    return Intl.message(
      'Add notes to your dish',
      name: 'addNotesToYourDish',
      desc: '',
      args: [],
    );
  }

  String get exampleMakeMyFoodSpicy {
    return Intl.message(
      'Example, make my food spicy!',
      name: 'exampleMakeMyFoodSpicy',
      desc: '',
      args: [],
    );
  }

  String get done {
    return Intl.message(
      'Done',
      name: 'done',
      desc: '',
      args: [],
    );
  }

  String get wantToChangeRestaurant {
    return Intl.message(
      'Want to change restaurant?',
      name: 'wantToChangeRestaurant',
      desc: '',
      args: [],
    );
  }

  String get changeRestaurantBodyContent {
    return Intl.message(
      'No problem! But just a heads up, we\'ll need to clear your current cart first',
      name: 'changeRestaurantBodyContent',
      desc: '',
      args: [],
    );
  }

  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  String get sureGoAhead {
    return Intl.message(
      'Sure, go ahead',
      name: 'sureGoAhead',
      desc: '',
      args: [],
    );
  }

  String get share {
    return Intl.message(
      'Share',
      name: 'share',
      desc: '',
      args: [],
    );
  }

  String get dishPrice {
    return Intl.message(
      'Dish Price',
      name: 'dishPrice',
      desc: '',
      args: [],
    );
  }

  String get addToCart {
    return Intl.message(
      'Add to Cart',
      name: 'addToCart',
      desc: '',
      args: [],
    );
  }

  String get openingHours {
    return Intl.message(
      'Opening Hours',
      name: 'openingHours',
      desc: '',
      args: [],
    );
  }

  String get myOrders {
    return Intl.message(
      'My Orders',
      name: 'myOrders',
      desc: '',
      args: [],
    );
  }

  String get orderAgain {
    return Intl.message(
      'Order again',
      name: 'orderAgain',
      desc: '',
      args: [],
    );
  }

  String get deliveryDetails {
    return Intl.message(
      'Delivery details',
      name: 'deliveryDetails',
      desc: '',
      args: [],
    );
  }

  String get deliverLocation {
    return Intl.message(
      'Deliver Location',
      name: 'deliverLocation',
      desc: '',
      args: [],
    );
  }

  String get weGotYourOrder {
    return Intl.message(
      'We got your order',
      name: 'weGotYourOrder',
      desc: '',
      args: [],
    );
  }

  String get diverIsHeadingToRestaurant {
    return Intl.message(
      'Diver is heading to Restaurant',
      name: 'diverIsHeadingToRestaurant',
      desc: '',
      args: [],
    );
  }

  String get orderItemss {
    return Intl.message(
      'Order items(s)',
      name: 'orderItemss',
      desc: '',
      args: [],
    );
  }

  String get paymentDetails {
    return Intl.message(
      'Payment Details',
      name: 'paymentDetails',
      desc: '',
      args: [],
    );
  }

  String get priceEstimated {
    return Intl.message(
      'Price (estimated)',
      name: 'priceEstimated',
      desc: '',
      args: [],
    );
  }

  String get convenienceFee {
    return Intl.message(
      'Convenience Fee',
      name: 'convenienceFee',
      desc: '',
      args: [],
    );
  }

  String get free {
    return Intl.message(
      'Free',
      name: 'free',
      desc: '',
      args: [],
    );
  }

  String get deliveryFee {
    return Intl.message(
      'Delivery fee',
      name: 'deliveryFee',
      desc: '',
      args: [],
    );
  }

  String get discounts {
    return Intl.message(
      'Discounts',
      name: 'discounts',
      desc: '',
      args: [],
    );
  }

  String get cash {
    return Intl.message(
      'Cash',
      name: 'cash',
      desc: '',
      args: [],
    );
  }

  String get needHelp {
    return Intl.message(
      'Need help',
      name: 'needHelp',
      desc: '',
      args: [],
    );
  }

  String get cancelOrder {
    return Intl.message(
      'Cancel order',
      name: 'cancelOrder',
      desc: '',
      args: [],
    );
  }

  String get logout {
    return Intl.message(
      'Logout',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  String get darkMode {
    return Intl.message(
      'Dark Mode',
      name: 'darkMode',
      desc: '',
      args: [],
    );
  }

  String get general {
    return Intl.message(
      'General',
      name: 'general',
      desc: '',
      args: [],
    );
  }

  String get location {
    return Intl.message(
      'Location',
      name: 'location',
      desc: '',
      args: [],
    );
  }

  String get searchForYourLocation {
    return Intl.message(
      'Search for your location',
      name: 'searchForYourLocation',
      desc: '',
      args: [],
    );
  }

  String get useCurrentLocation {
    return Intl.message(
      'Use current location',
      name: 'useCurrentLocation',
      desc: '',
      args: [],
    );
  }

  String get savedAddress {
    return Intl.message(
      'Saved Address',
      name: 'savedAddress',
      desc: '',
      args: [],
    );
  }

  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  String get recentLocations {
    return Intl.message(
      'Recent Locations',
      name: 'recentLocations',
      desc: '',
      args: [],
    );
  }

  String get change {
    return Intl.message(
      'CHANGE',
      name: 'change',
      desc: '',
      args: [],
    );
  }

  String get selectDeliveryLocation {
    return Intl.message(
      'Select delivery location',
      name: 'selectDeliveryLocation',
      desc: '',
      args: [],
    );
  }

  String get confirmLocation {
    return Intl.message(
      'CONFIRM LOCATION',
      name: 'confirmLocation',
      desc: '',
      args: [],
    );
  }

  String get addMore {
    return Intl.message(
      '+ Add more',
      name: 'addMore',
      desc: '',
      args: [],
    );
  }

  String get yayYouSaved {
    return Intl.message(
      'Yay! You saved',
      name: 'yayYouSaved',
      desc: '',
      args: [],
    );
  }

  String get onThisOrder {
    return Intl.message(
      'on this order',
      name: 'onThisOrder',
      desc: '',
      args: [],
    );
  }

  String get delivery {
    return Intl.message(
      'Delivery',
      name: 'delivery',
      desc: '',
      args: [],
    );
  }

  String get moreInfo {
    return Intl.message(
      'More info',
      name: 'moreInfo',
      desc: '',
      args: [],
    );
  }

  String get totalPayment {
    return Intl.message(
      'Total payment',
      name: 'totalPayment',
      desc: '',
      args: [],
    );
  }

  String get promo {
    return Intl.message(
      'Promo',
      name: 'promo',
      desc: '',
      args: [],
    );
  }

  String get gofoodPartnerDiscount {
    return Intl.message(
      'Gofood partner discount',
      name: 'gofoodPartnerDiscount',
      desc: '',
      args: [],
    );
  }

  String get restoOffer {
    return Intl.message(
      'Resto offer',
      name: 'restoOffer',
      desc: '',
      args: [],
    );
  }

  String get convenienceFeeIsAFeeForOrderingThroughGofood {
    return Intl.message(
      'Convenience fee is a fee for ordering through GoFood',
      name: 'convenienceFeeIsAFeeForOrderingThroughGofood',
      desc: '',
      args: [],
    );
  }

  String get forYourEasePleaseMakeSureYourOrderDoesntNeed {
    return Intl.message(
      'For your ease, please make sure your order doesn\'t need changes.',
      name: 'forYourEasePleaseMakeSureYourOrderDoesntNeed',
      desc: '',
      args: [],
    );
  }

  String get disclaimerFinalPriceMayChangeSlightlyIfTheRestaurantHas {
    return Intl.message(
      'Disclaimer: final price may change slightly if the restaurant has updates prices.',
      name: 'disclaimerFinalPriceMayChangeSlightlyIfTheRestaurantHas',
      desc: '',
      args: [],
    );
  }

  String get selectPaymentMethod {
    return Intl.message(
      'Select payment method',
      name: 'selectPaymentMethod',
      desc: '',
      args: [],
    );
  }

  String get yourBalance {
    return Intl.message(
      'Your balance',
      name: 'yourBalance',
      desc: '',
      args: [],
    );
  }

  String get topUp {
    return Intl.message(
      'Top up',
      name: 'topUp',
      desc: '',
      args: [],
    );
  }

  String get confirmPassword {
    return Intl.message(
      'Confirm Password',
      name: 'confirmPassword',
      desc: '',
      args: [],
    );
  }

  String get orLoginWith {
    return Intl.message(
      'Or Login With',
      name: 'orLoginWith',
      desc: '',
      args: [],
    );
  }

  String get login {
    return Intl.message(
      'login',
      name: 'login',
      desc: '',
      args: [],
    );
  }

  String get open {
    return Intl.message(
      'OPEN',
      name: 'open',
      desc: '',
      args: [],
    );
  }

  String get myFavourites {
    return Intl.message(
      'My Favourites',
      name: 'myFavourites',
      desc: '',
      args: [],
    );
  }

  String get myProfile {
    return Intl.message(
      'My Profile',
      name: 'myProfile',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
      Locale.fromSubtags(languageCode: 'ta'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    if (locale != null) {
      for (var supportedLocale in supportedLocales) {
        if (supportedLocale.languageCode == locale.languageCode) {
          return true;
        }
      }
    }
    return false;
  }
}