import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/router.dart';
import 'package:foodstar/src/constants/common_strings.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/provider_viewmodels/auth/auth_view_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/language_changer.dart';
import 'package:foodstar/src/core/provider_viewmodels/theme_changer.dart';
import 'package:foodstar/src/core/service/api_base_helper.dart';
import 'package:foodstar/src/ui/res/style.dart';
import 'package:foodstar/src/ui/splash_screen.dart';
import 'package:provider/provider.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider.value(
          value: ApiBaseHelper(),
        ),
        ChangeNotifierProvider(
          create: (context) => AuthViewModel(context: context),
        ),
        ChangeNotifierProvider(
          create: (context) => ThemeManager(),
        ),
        ChangeNotifierProvider(
          create: (context) => LanguageManager(),
        ),
        // Provider<ValueNotifier<GraphQLClient>>.value(value: ApiClient.client),
      ],
      child: Consumer3<ThemeManager, LanguageManager, AuthViewModel>(
        builder: (context, appTheme, locale, auth, child) {
          return MaterialApp(
            title: CommonStrings.appName,
            debugShowCheckedModeBanner: false,
            theme: appTheme.darkMode ? dark : light,
            onGenerateRoute: Router.generateRoute,
            locale: locale.appLocale,
            localizationsDelegates: [
              S.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            supportedLocales: S.delegate.supportedLocales,
            home: (auth.authState == AuthState.authenticated ||
                    auth.authState == AuthState.authSkiped)
                ? SplashScreen(nxtScreen: mainHome)
                : SplashScreen(nxtScreen: login),
          );
        },
      ),
    );
  }

  moveToNextScreen(String routeName) {
    SplashScreen(
      nxtScreen: routeName,
    );
  }

//  initPref() async {
//    if (prefs == null) prefs = await SharedPreferences.getInstance();
//  }
//
//  Future<bool> checkLoginSkipOrNot() async {
//    await initPref();
//    return prefs.getBool(SharedPreferenceKeys.loginSkipped) ?? false;
//  }
}
