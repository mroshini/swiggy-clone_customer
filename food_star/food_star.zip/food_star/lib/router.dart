import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/ui/routes/auth/change_password.dart';
import 'package:foodstar/src/ui/routes/auth/forgot_password_screen.dart';
import 'package:foodstar/src/ui/routes/auth/login_screen.dart';
import 'package:foodstar/src/ui/routes/auth/otp_screen.dart';
import 'package:foodstar/src/ui/routes/auth/register_screen.dart';
import 'package:foodstar/src/ui/routes/auth/reset_password_screen.dart';
import 'package:foodstar/src/ui/routes/cart/cart.dart';
import 'package:foodstar/src/ui/routes/favorites.dart';
import 'package:foodstar/src/ui/routes/food_star_screen.dart';
import 'package:foodstar/src/ui/routes/location/manage_address.dart';
import 'package:foodstar/src/ui/routes/location/search_location.dart';
import 'package:foodstar/src/ui/routes/location/show_delivery_location_map_screen.dart';
import 'package:foodstar/src/ui/routes/location/show_location_map.dart';
import 'package:foodstar/src/ui/routes/main_home.dart';
import 'package:foodstar/src/ui/routes/my_account/change_language.dart';
import 'package:foodstar/src/ui/routes/my_account/edit_profile.dart';
import 'package:foodstar/src/ui/routes/my_account/invite_friends.dart';
import 'package:foodstar/src/ui/routes/my_account/terms_and_policy.dart';
import 'package:foodstar/src/ui/routes/orders/my_orders.dart';
import 'package:foodstar/src/ui/routes/restaurant_details/restaurant_details_root.dart';
import 'package:foodstar/src/ui/routes/search/search_restaturants_list.dart';
import 'package:foodstar/src/ui/routes/search/sort_filter_screen.dart';

import 'src/ui/routes/orders/success_order.dart';

class Router {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case showLocationMapScreen:
        return MaterialPageRoute(
          builder: (_) => ShowLocationMapScreen(
            screenStatus: settings.arguments,
          ),
        );
      case successOrder:
        return MaterialPageRoute(
          builder: (_) => SuccessOrderScreen(),
        );
      case termsOfService:
        return MaterialPageRoute(
          builder: (_) => TermsOfServiceScreen(screenName: settings.arguments),
        );
      case inviteFriendsScreen:
        return MaterialPageRoute(
          builder: (_) => InviteFriendsScreen(),
        );
      case manageAddress:
        return MaterialPageRoute(
          builder: (_) => ManageAddressScreen(),
        );
      case editProfile:
        return MaterialPageRoute(
          builder: (_) => EditProfileScreen(
            profileInfo: settings.arguments,
          ),
        );
      case language:
        return MaterialPageRoute(
          builder: (_) => ChangeLanguageScreen(),
        );
      case myOrders:
        return MaterialPageRoute(
          builder: (_) => MyOrdersScreen(),
        );
      case favorites:
        return MaterialPageRoute(
          builder: (_) => FavoritesScreen(),
        );
      case login:
        return MaterialPageRoute(
          builder: (_) => LoginScreen(),
        );
      case register:
        return MaterialPageRoute(
          builder: (_) => RegisterScreen(),
        );
      case otp:
        return MaterialPageRoute(
          builder: (_) => OtpScreen(otpInfo: settings.arguments),
        );
      case forgetPassword:
        return MaterialPageRoute(
          builder: (_) => ForgotPasswordScreen(),
        );
      case changePassword:
        return MaterialPageRoute(
          builder: (_) => ChangePassword(),
        );
      case resetPassword:
        return MaterialPageRoute(
          builder: (_) => ResetPasswordScreen(args: settings.arguments),
        );
      case sortFilter:
        return MaterialPageRoute(
          builder: (_) => SortFilterScreen(),
        );
      case mainHome:
        return MaterialPageRoute(
          builder: (_) =>
              HomeScreen(selectedIndexFromRoutedScreen: settings.arguments),
        );
      case foodStarHome:
        return MaterialPageRoute(
          builder: (_) => FoodStarScreen(),
        );
      case search:
        return MaterialPageRoute(
          builder: (_) => SearchScreen(),
        );
      case cart:
        return MaterialPageRoute(
          builder: (_) => CartScreen(showArrow: settings.arguments),
        );
      case restaurantDetails:
        return MaterialPageRoute(
          builder: (_) => RestaurantDetailScreen(
            imageInfo: settings.arguments,
          ),
        );
      case searchLocation:
        return MaterialPageRoute(
          builder: (_) => SearchLocationScreen(),
        );
      case deliveryLocationMapView:
        return MaterialPageRoute(
          builder: (_) => DeliveryLocationMapView(),
        );
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text(
                'No route found for the name $settings.name',
              ),
            ),
          ),
        );
    }
  }
}
