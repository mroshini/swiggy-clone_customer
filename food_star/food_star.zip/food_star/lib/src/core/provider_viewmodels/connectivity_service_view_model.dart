import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';

enum ConnectivityStatus { WiFi, Cellular, Offline }

class ConnectivityServiceModel extends ChangeNotifier {
  ConnectivityStatus connectionStatusController;

  ConnectivityServiceModel() {
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      connectionStatusController = _getStatusFromResult(result);
      notifyListeners();
    });
  }

  ConnectivityStatus _getStatusFromResult(ConnectivityResult result) {
    switch (result) {
      case ConnectivityResult.mobile:
        return ConnectivityStatus.Cellular;
      case ConnectivityResult.wifi:
        return ConnectivityStatus.WiFi;
      case ConnectivityResult.none:
        return ConnectivityStatus.Offline;
      default:
        return ConnectivityStatus.Offline;
    }
  }
}
