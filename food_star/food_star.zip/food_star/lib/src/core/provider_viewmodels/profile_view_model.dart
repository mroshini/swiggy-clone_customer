import 'dart:io';

import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/api_urls.dart';
import 'package:foodstar/src/core/models/api_models/auth_common_response_model.dart';
import 'package:foodstar/src/core/models/api_models/edit_profile_model.dart';
import 'package:foodstar/src/core/models/db_model/profile_db_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/common/base_change_notifier_model.dart';
import 'package:foodstar/src/core/service/api_repository.dart';
import 'package:foodstar/src/core/service/database/database_helper.dart';
import 'package:foodstar/src/core/service/database/database_statics.dart';

//enum ResponseState { initial, loading, success, loaded, error }

class ProfileViewModel extends BaseChangeNotifierModel {
  BuildContext context;
  UserProfileDbModel userInfo;
  DBHelper dbHelper;
  String name = "";
  String emailAddress = "";
  String number = "";
  String sampleImageSource = "";
  int emailVerifiedStatus = 0;
  int phoneCode = 0;
  String lastUpdatedAt = "0";
  var response;

  ProfileViewModel({this.context}) {
    initDbHelper();
  }

  initDbHelper() {
    dbHelper = DBHelper.instance;
  }

  getUserProfileDetails() async {
    setState(BaseViewState.Busy);
    var response = await getProfileDataFromDb();
    showLog("UserProfileDbModel  ${response}");
    if (lastUpdatedAt == "0") {
      // call api then load data from db
      setState(BaseViewState.Busy);
      await callProfileApi();
      await getProfileDataFromDb();
      setState(BaseViewState.Idle);
    } else {
      setState(BaseViewState.Idle);
      await getProfileDataFromDb();
      await callProfileApi();
      setState(BaseViewState.Idle);
    }
    // await getProfileDataFromDb();
  }

  getProfileDataFromDb() async {
    await dbHelper.getProfileData().then((value) => {
          if (value != null)
            {
              name = value.username,
              lastUpdatedAt = value.updatedAt == "" ? "0" : value.updatedAt,
              emailAddress = value.email,
              emailVerifiedStatus = value.emailVerified,
              sampleImageSource = value.src,
              number = value.phoneNumber.toString(),
              phoneCode = value.phoneCode,
              showLog(
                  "getProfileDataFromDb -- ${name} --${lastUpdatedAt} --${emailVerifiedStatus} ${emailAddress} ${sampleImageSource}")
            }
        });

    notifyListeners();
  }

  callProfileApi() async {
    //setState(ViewState.Busy);
    try {
      var result = await ApiRepository(mContext: context)
          .userProfileDetailsRequest(updatedAt: lastUpdatedAt)
          .then((value) => {storeProfileDataInDb(value)});
      // setState(BaseViewState.Idle);
      return result;
    } catch (e) {
      showLog("AuthViewModel,$e");
      // setState(ViewState.Idle);
      return null;
      //  _showAlertDialog(context: context, errorMessage: e);
    }
  }

  storeProfileDataInDb(dynamic value) async {
    userInfo = UserProfileDbModel(
        username: value.user.username,
        email: value.user.email,
        phoneNumber: value.user.phoneNumber,
        src: value.user.src,
        phoneCode: value.user.phoneCode,
        emailVerified: value.user.emailVerified,
        updatedAt: value.user.updatedAt);
    await dbHelper.insert(userInfo.toJson(), DbStatics.tableProfile);
  }

  Future<CommonMessageModel> verifyEmailRequest(String emailAddress) async {
    setState(BaseViewState.Busy);
    try {
      var result = await ApiRepository(mContext: context)
          .verifyEmailRequestFromProfile(emailAddress);
      setState(BaseViewState.Idle);
      return result;
    } catch (e) {
      showLog("AuthViewModel,$e");
      setState(BaseViewState.Idle);
      return null;
      //  _showAlertDialog(context: context, errorMessage: e);
    }
  }

  Future<EditProfileApiModel> editProfileRequest({
    Map<String, dynamic> dynamicAuthMap,
    Map<String, String> staticAuthMap,
    String url,
    int urlType,
    File fileName,
  }) async {
    setState(BaseViewState.Busy);
    try {
      var result = await ApiRepository(mContext: context).editProfileRequest(
        url: url,
        dynamicMapValue: dynamicAuthMap,
        staticAuthMap: staticAuthMap,
        urlType: urlType,
        fileName: fileName,
      );

      setState(BaseViewState.Idle);
      return result;
    } catch (e) {
      showLog("AuthViewModel,$e");
      setState(BaseViewState.Idle);
      return null;
      //  _showAlertDialog(context: context, errorMessage: e);
    }
  }
}
