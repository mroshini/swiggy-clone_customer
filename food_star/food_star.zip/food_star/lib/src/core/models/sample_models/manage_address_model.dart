import 'package:flutter/material.dart';

class ManageAddressModel {
  String lineOne;
  String lineTwo;
  IconData iconValue;

  ManageAddressModel({
    this.lineOne,
    this.lineTwo,
    this.iconValue,
  });
}
