import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/common_strings.dart';
import 'package:foodstar/src/core/models/sample_models/my_account_model.dart';

class MyAccountData {
  List<MyAccountHeaderModel> myAccount = [
    MyAccountHeaderModel(
        title: CommonStrings.account, bodyModel: bodyAccountDataOne),
    MyAccountHeaderModel(
        title: CommonStrings.general, bodyModel: bodyAccountDataTwo),
  ];

  static List<MyAccountBodyModel> bodyAccountDataOne = [
    MyAccountBodyModel(
      accountIcon: Icons.playlist_add_check,
      bodyTitle: CommonStrings.myOrders,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.local_offer,
      bodyTitle: CommonStrings.favourites,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.edit_location,
      bodyTitle: CommonStrings.manageAddress,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.settings_backup_restore,
      bodyTitle: CommonStrings.changePassword,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.payment,
      bodyTitle: CommonStrings.payment,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.language,
      bodyTitle: CommonStrings.changeLanguage,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.help_outline,
      bodyTitle: CommonStrings.changeCurrency,
    ),
    MyAccountBodyModel(
      accountIcon: Icons.people_outline,
      bodyTitle: CommonStrings.inviteFriends,
    ),
  ];

  static List<MyAccountBodyModel> bodyAccountDataTwo = [
    MyAccountBodyModel(
      accountIcon: Icons.description,
      bodyTitle: 'Privacy Policy',
    ),
    MyAccountBodyModel(
      accountIcon: Icons.note,
      bodyTitle: 'Terms Of Service',
    )
  ];
}
