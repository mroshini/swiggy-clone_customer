class ApiResponseModel {
  int statusCode;
  dynamic response;

  ApiResponseModel({
    this.statusCode,
    this.response,
  });
}
