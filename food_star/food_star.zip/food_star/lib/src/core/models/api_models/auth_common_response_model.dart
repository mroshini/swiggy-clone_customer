import 'dart:convert';

CommonMessageModel commonMessageModelFromJson(str) =>
    CommonMessageModel.fromJson(json.decode(str));

String commonMessageModelToJson(CommonMessageModel data) =>
    json.encode(data.toJson());

class CommonMessageModel {
  String message;

  CommonMessageModel({this.message});

  factory CommonMessageModel.fromJson(Map<String, dynamic> json) {
    return CommonMessageModel(
      message: json['message'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    return data;
  }
}
