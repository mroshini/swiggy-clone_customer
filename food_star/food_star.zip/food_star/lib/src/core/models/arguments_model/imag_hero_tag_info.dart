class ImageHeroTagInfo {
  final String tag;
  final String image;

  ImageHeroTagInfo(this.tag, this.image);
}
