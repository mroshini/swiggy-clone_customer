class AuthArgumentsModel {
  final String emailOrCode;
  final String info;

  AuthArgumentsModel({this.emailOrCode, this.info});
}
