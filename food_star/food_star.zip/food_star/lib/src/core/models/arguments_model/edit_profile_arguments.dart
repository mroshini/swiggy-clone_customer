class EditProfileArguments {
  final String name;
  final String phoneNumber;
  final String email;
  final String image;
  final String phoneCode;

  EditProfileArguments(
      {this.name, this.phoneNumber, this.email, this.image, this.phoneCode});
}
