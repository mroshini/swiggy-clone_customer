class DbStatics {
  ///common
  static const _createTable = 'CREATE TABLE';
  static const _integer = 'INTEGER';
  static const _text = 'TEXT';
  static const _primaryKey = 'PRIMARY KEY';

  static const id = 'id';
  static const name = 'name';
  static const url = 'url';
  static const userRandomId = 'user_random_id';
  static const lastUpdatedAt = 'updated_at';
  static const phoneCode = 'phone_code';

  /// countries Table

  static const tableCountryCode = 'countryCode';
  static const countryID = '$id';
  static const countryName = '$name';
  static const countryCode = '$phoneCode';

  static const createCountryTable =
      '$_createTable $tableCountryCode ($countryID $_integer $_primaryKey,'
      '$countryName $_text, $countryCode $_integer)';

  // ProfileTable
  static const tableProfile = 'profile';
  static const profileName = 'username';
  static const profileEmail = 'email';
  static const profileNumber = 'phone_number';
  static const profileImageSrc = 'src';
  static const profilePhoneCode = '$phoneCode';
  static const profileEmailVerifiedStatus = 'email_verified';
  static const profileUpdatedAt = '$lastUpdatedAt';

  static const createProfileTable = '$_createTable $tableProfile '
      '($profileName $_text $_primaryKey,$profileEmail $_text,'
      '$profileNumber $_integer, $profileImageSrc $_text, $profilePhoneCode $_integer,'
      '$profileEmailVerifiedStatus $_integer,$profileUpdatedAt $_text)';
}
