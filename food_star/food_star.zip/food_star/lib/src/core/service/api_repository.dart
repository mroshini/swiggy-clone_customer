import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:foodstar/src/constants/api_params_keys.dart';
import 'package:foodstar/src/constants/api_urls.dart';
import 'package:foodstar/src/constants/sharedpreference_keys.dart';
import 'package:foodstar/src/core/models/api_models/app_essensial_core_data_model.dart';
import 'package:foodstar/src/core/models/api_models/auth_common_response_model.dart';
import 'package:foodstar/src/core/models/api_models/edit_profile_model.dart';
import 'package:foodstar/src/core/models/api_models/login_response_model.dart';
import 'package:foodstar/src/core/models/api_models/register_response_model.dart';
import 'package:foodstar/src/core/models/api_models/user_profile_model.dart';
import 'package:foodstar/src/core/models/db_model/country_code_db_model.dart';
import 'package:foodstar/src/core/service/api_base_helper.dart';
import 'package:foodstar/src/core/service/database/database_helper.dart';
import 'package:foodstar/src/core/service/database/database_statics.dart';
import 'package:foodstar/src/utils/shared_preference_utils.dart';
import 'package:foodstar/src/utils/target_platform.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ApiRepository {
  ApiBaseHelper apiHelper;
  SharedPreferences prefs;
  String clientId;
  String clientSecret;
  BuildContext mContext;
  DBHelper dbHelper;

  ApiRepository({this.mContext}) {
    apiHelper = Provider.of<ApiBaseHelper>(mContext, listen: false);
    SharedPreferenceUtils.init();
  }

  initDbHelper() {
    dbHelper = DBHelper.instance;
  }

  initPref() async {
    if (prefs == null) prefs = await SharedPreferences.getInstance();
  }

  //url type 1-post,2-get, 3-put
  fetchAppEssentialCorerData() async {
    initDbHelper();
    Countries countryCodeData;
    var coreDataMap = {deviceKey: fetchTargetPlatform()};

    final response = await apiHelper.apiRequest(
        url: coreData,
        dynamicMapValue: coreDataMap,
        urlType: post,
        context: mContext);

    showLog('AppEssentialsCoreDataModel ${response}');

    compute(appEssentialsCoreDataModelFromJson, response).then((value) => {
          storeCoreData(value.aClient.id, value.aClient.secret),
          for (int i = 0; i <= value.aCountries.length - 1; i++)
            {
              countryCodeData = Countries(
                id: value.aCountries[i].id,
                name: value.aCountries[i].name,
                phoneCode: value.aCountries[i].phoneCode,
              )
            },
          dbHelper.insert(countryCodeData.toJson(), DbStatics.tableCountryCode)
        });
  }

  storeCoreData(String clientID, String clientSecret) async {
    showLog('AppEssentialsCoreDataModel ${clientID} ${clientSecret}');
    await initPref();

    prefs.setString(SharedPreferenceKeys.clientId, clientID);
    prefs.setString(SharedPreferenceKeys.clientSecret, clientSecret);
  }

  Future<dynamic> authApiRequest({
    String url,
    Map<String, dynamic> dynamicMapValue,
    Map<String, String> staticMapValue,
    int urlType,
    int model,
  }) async {
    final response = await apiHelper.apiRequest(
        url: url,
        dynamicMapValue: dynamicMapValue,
        staticMapValue: staticMapValue,
        urlType: urlType);

    showLog("authApiRequest -- ${response}");
    if (model == 1) {
      return compute(registerResponseModelFromJson, response);
    } else if (model == 2) {
      //login
      return compute(loginResponseModelFromJson, response);
    } else {
      return compute(commonMessageModelFromJson, response);
    }
  }

  Future<dynamic> userProfileDetailsRequest({String updatedAt}) async {
    final response = await apiHelper.apiRequest(
        url: userProfileDetails,
        staticMapValue: {
          userTypeKey: userType,
          updatedAtKey: updatedAt,
        },
        urlType: getUrl);
    return compute(userProfileApiModelFromJson, response);
  }

  Future<dynamic> verifyEmailRequestFromProfile(String email) async {
    final response = await apiHelper.apiRequest(
        url: verifyEmailRequestUrl,
        staticMapValue: {userTypeKey: userType, emailKey: email},
        urlType: put);

    showLog("userProfileDetailsRequest -- ${response}");
    return compute(commonMessageModelFromJson, response);
  }

  Future<dynamic> editProfileRequest({
    Map<String, dynamic> dynamicMapValue,
    Map<String, String> staticAuthMap,
    String url,
    int urlType,
    File fileName,
  }) async {
    final response = await apiHelper.apiRequest(
        url: url,
        dynamicMapValue: dynamicMapValue,
        staticMapValue: staticAuthMap,
        urlType: urlType,
        fileName: fileName);

    showLog("editProfileRequest -- ${response}");
    return compute(editProfileApiModelFromJson, response);
  }
}
