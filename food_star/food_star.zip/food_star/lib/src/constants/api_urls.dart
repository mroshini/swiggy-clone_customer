library api_urls;

const int post = 1;
const int getUrl = 2;
const int put = 3;
const int multipart = 4;

const groupId = "4";
const userType = "user";
const isLogEnabled = true;
const baseUrl = 'https://www.abservetechdemo.com/products/foodstar-dev/api/';
const baseUrlGetRequest = 'www.abservetechdemo.com';
const baseGetUrlPath = '/products/foodstar-dev/api/';

const coreData = 'coreDatas';
const registerUrl = 'register'; // singup
const loginUrl = 'signin'; //signin
const activeAccount = 'activeAccount';
const forgetPasswordUrl = 'forgetPasswordrequest';
const resetPasswordUrl = 'resetPassword';
const changePasswordUrl = 'user/changePassword';
const editProfileUrl = "user/editprofile";
const verifyEmailRequestUrl = "user/verifyEmailRequest";
const verifyEmailWithCode = "user/verifyEmail";
const userProfileDetails = "user/profile";

const webUrl = 'http://abservetechdemo.com/products/foodstar-dev';

showLog(message) {
  if (isLogEnabled) {
    print(message);
  } else {}
}
