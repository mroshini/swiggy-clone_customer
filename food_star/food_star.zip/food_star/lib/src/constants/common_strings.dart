class CommonStrings {
  static final RegExp mobileRegEx = RegExp(r'(^(?:[+0]9)?[0-9]{10,11}$)');
  static final RegExp emailRegEx = RegExp(
      "^[a-zA-Z0-9.!#\$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?)*\$");

  static const appName = 'FoodStar';
  static const myOrders = 'My Orders';
  static const favourites = 'My Favourites';
  static const manageAddress = 'Manage Address';
  static const payment = "Payment";
  static const changePassword = "Change Password";
  static const changeLanguage = "Change Language";
  static const changeCurrency = "Change Currency";
  static const inviteFriends = "Invite Friends";
  static const privacyPolicy = "Privacy Policy";
  static const termsOfService = "Terms Of Service";
  static const account = "Account";
  static const general = "General";
}
