library api_params_keys;

//core datas
const deviceKey = 'device';

//Register
const userNameKey = 'username';
const emailKey = 'email';
const passwordKey = 'password';
const phoneNumberKey = 'phone_number';
const phoneCodeKey = 'phone_code';
const groupIdKey = 'group_id';
const typeKey = 'type';

//login
const clientIdKey = "client_id";
const clientSecretKey = "client_secret";
const grantTypeKey = "grant_type";
const mobileTokenKey = 'mobile_token';
const deviceIDKey = 'device_id';
const userTypeKey = 'user_type';
const oldPasswordKey = 'old_password';
const newPasswordKey = 'new_password';
const imageFilePathKey = 'imageFile';
const updatedAtKey = 'updated_at';
// profile
const avatarKey = 'avatar';
//password
const passwordConfirmationKey = 'password_confirmation';

//active account
const codeKey = 'code';
