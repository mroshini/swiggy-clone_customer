class SharedPreferenceKeys {
  static const isloggedIn = 'loggedIn';
  static const languageCode = 'app-language';
  static const onboard = 'onboard';
  static const accessToken = 'access-token';
  static const user = 'user';
  static const theme = 'theme';
  static const firebaseToken = 'firebase_token';
  static const translateLanguageCode = 'language_code';
  static const countryCode = 'countryCode';
  static const selectedIndex = 'index';
  static const clientId = 'client_id';
  static const clientSecret = 'client_secret';
  static const loginSkipped = 'skip_login';
}
