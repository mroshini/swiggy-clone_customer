import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/constants/common_strings.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/arguments_model/edit_profile_arguments.dart';
import 'package:foodstar/src/core/models/sample_models/my_account_data.dart';
import 'package:foodstar/src/core/models/sample_models/my_account_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/common/base_change_notifier_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/common/base_widget.dart';
import 'package:foodstar/src/core/provider_viewmodels/profile_view_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/theme_changer.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/restaurant_info_list_shimmer.dart';
import 'package:provider/provider.dart';

class MyAccountScreen extends StatefulWidget {
  @override
  _MyAccountScreenState createState() => _MyAccountScreenState();
}

class _MyAccountScreenState extends State<MyAccountScreen> {
  final List<MyAccountHeaderModel> myAccountData = MyAccountData().myAccount;
  var profileModel;

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1.0,
        title: Text(
          S.of(context).myProfile,
          style: Theme.of(context).textTheme.subhead,
        ),
      ),
      body: BaseWidget<ProfileViewModel>(
        model: ProfileViewModel(context: context),
        onModelReady: (model) => model.getUserProfileDetails(),
        builder: (BuildContext context, ProfileViewModel model, Widget child) {
          return LayoutBuilder(builder:
              (BuildContext context, BoxConstraints viewportConstraints) {
            return Column(
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: viewportConstraints.maxHeight,
                      ),
                      child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            verticalSizedBox(),
                            model.state == BaseViewState.Busy
                                ? showShimmer(context)
                                : Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Flexible(
                                          flex: 2,
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              CircleAvatar(
                                                child: CachedNetworkImage(
                                                  imageUrl:
                                                      model.sampleImageSource,
                                                  placeholder: (context, url) =>
                                                      CircularProgressIndicator(),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          Icon(Icons.error),
                                                  fit: BoxFit.fill,
                                                ),
                                              ),
                                              horizontalSizedBoxTwenty(),
                                              Flexible(
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      model.name,
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .headline,
                                                    ),
                                                    verticalSizedBox(),
                                                    Text(
                                                      "${model.phoneCode} ${model.number}",
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .display2,
                                                    ),
                                                    verticalSizedBox(),
                                                    Row(
                                                      children: <Widget>[
                                                        Text(
                                                          model.emailAddress,
                                                          style:
                                                              Theme.of(context)
                                                                  .textTheme
                                                                  .display2,
                                                        ),
                                                        horizontalSizedBox(),
                                                        Flexible(
                                                          child: Visibility(
                                                            visible:
                                                                model.emailVerifiedStatus ==
                                                                        1
                                                                    ? true
                                                                    : false,
                                                            child: InkWell(
                                                              onTap: () {
                                                                model
                                                                    .verifyEmailRequest(
                                                                        model
                                                                            .emailAddress)
                                                                    .then(
                                                                      (value) =>
                                                                          {
                                                                        if (value !=
                                                                            null)
                                                                          {
                                                                            Navigator.pushNamed(
                                                                              context,
                                                                              otp,
                                                                              arguments: {
                                                                                "message": value.message,
                                                                                "email": model.emailAddress,
                                                                                "type": 0
                                                                              },
                                                                            ),
                                                                          },
                                                                      },
                                                                    );
                                                              },
                                                              child: model.state ==
                                                                      BaseViewState
                                                                          .Busy
                                                                  ? CircularProgressIndicator
                                                                  : Text(
                                                                      "Verify email",
                                                                      style: Theme.of(
                                                                              context)
                                                                          .textTheme
                                                                          .display1
                                                                          .copyWith(
                                                                            color:
                                                                                darkRed,
                                                                          ),
                                                                    ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            Navigator.pushNamed(
                                              context,
                                              editProfile,
                                              arguments: EditProfileArguments(
                                                name: model.name,
                                                phoneNumber: model.number,
                                                email: model.emailAddress,
                                                phoneCode: "${model.phoneCode}",
                                                image: model.sampleImageSource,
                                              ),
                                            );
                                          },
                                          child: Icon(
                                            Icons.edit,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                            verticalSizedBox(),
                            Consumer<ThemeManager>(
                                builder: (context, appTheme, child) {
                              return SwitchListTile(
                                title: Text(
                                  S.of(context).darkMode,
                                  style: Theme.of(context).textTheme.display1,
                                ),
                                onChanged: (val) {
                                  appTheme.changeTheme();
                                },
                                value: appTheme.darkMode,
                              );
                            }),
                            ListView.builder(
                                itemCount: myAccountData.length,
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemBuilder: (context, parentIndex) {
                                  return Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: <Widget>[
                                        Text(
                                          myAccountData[parentIndex].title,
                                          style: Theme.of(context)
                                              .textTheme
                                              .display1,
                                        ),
                                        verticalSizedBoxTwenty(),
                                        ListView.builder(
                                          itemCount: myAccountData[parentIndex]
                                              .bodyModel
                                              .length,
                                          shrinkWrap: true,
                                          physics:
                                              NeverScrollableScrollPhysics(),
                                          itemBuilder: (context, index) {
                                            return Material(
                                              color: transparent,
                                              child: InkWell(
                                                onTap: () {
                                                  moveToRespectivePage(
                                                      myAccountData[parentIndex]
                                                          .bodyModel[index]
                                                          .bodyTitle);
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    border: Border(
                                                      bottom: BorderSide(
                                                        //                   <--- left side
                                                        color: Colors.grey[100],
                                                        width: 1.0,
                                                      ),
                                                    ),
                                                  ),
                                                  child: Padding(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            8.0),
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: <Widget>[
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            horizontalSizedBox(),
                                                            Icon(
                                                              myAccountData[
                                                                      parentIndex]
                                                                  .bodyModel[
                                                                      index]
                                                                  .accountIcon,
                                                              size: 25.0,
                                                            ),
                                                            horizontalSizedBox(),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                      .all(5.0),
                                                              child: Text(
                                                                myAccountData[
                                                                        parentIndex]
                                                                    .bodyModel[
                                                                        index]
                                                                    .bodyTitle,
                                                                style: Theme.of(
                                                                        context)
                                                                    .textTheme
                                                                    .display1,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Icon(
                                                              Icons
                                                                  .arrow_forward_ios,
                                                              color:
                                                                  Colors.grey,
                                                              size: 15.0,
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                        verticalSizedBox(),
                                      ],
                                    ),
                                  );
                                }),
                            verticalSizedBox(),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                width: MediaQuery.of(context).size.width,
                                child: OutlineButton(
                                  splashColor: Colors.grey,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                      30,
                                    ),
                                  ),
                                  highlightElevation: 0,
                                  borderSide: BorderSide(color: Colors.grey),
                                  child: Padding(
                                    padding: const EdgeInsets.only(
                                        left: 0,
                                        top: 12,
                                        right: 10,
                                        bottom: 12),
                                    child: Text(
                                      S.of(context).logout,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display1
                                          .copyWith(
                                            color: Colors.grey,
                                          ),
                                    ),
                                  ),
                                  onPressed: () {},
                                ),
                              ),
                            ),
                          ]),
                    ),
                  ),
                ),
              ],
            );
          });
        },
      ),
    );
  }

  moveToRespectivePage(String title) {
    switch (title) {
      case CommonStrings.favourites:
        return Navigator.of(context).pushNamed(
          favorites,
        );
      case CommonStrings.myOrders:
        return Navigator.of(context).pushNamed(
          myOrders,
        );
      case CommonStrings.changeLanguage:
        return Navigator.of(context).pushNamed(
          language,
        );
      case CommonStrings.inviteFriends:
        return Navigator.of(context).pushNamed(
          inviteFriendsScreen,
        );
      case CommonStrings.changePassword:
        return Navigator.of(context).pushNamed(
          changePassword,
        );
      case CommonStrings.termsOfService:
        return Navigator.of(context).pushNamed(
          termsOfService,
        );
      case CommonStrings.privacyPolicy:
        return Navigator.of(context).pushNamed(
          termsOfService,
          arguments: (1),
        );
      case CommonStrings.manageAddress:
        return Navigator.of(context).pushNamed(
          manageAddress,
        );
      default:
        return Scaffold(
          body: Container(
            color: white,
          ),
        );
    }
  }
}
