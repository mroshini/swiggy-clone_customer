import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/sample_models/home_model_data.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/home_search_listView_widget.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/common_navigation.dart';
import 'package:foodstar/src/utils/restaurant_info_list_shimmer.dart';

class FoodStarScreen extends StatefulWidget {
  @override
  _FoodStarScreenState createState() => _FoodStarScreenState();
}

class _FoodStarScreenState extends State<FoodStarScreen> {
  var _homeInfo = HomeModelData().homeInfo;
  var _imagePath = HomeModelData().imagePath;
  bool showRestaurantList = false;

  @override
  void initState() {
    super.initState();
    // create a future delayed function that will change showInagewidget to true after 5 seconds

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        showRestaurantList = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 1.0,
        title: Material(
          color: transparent,
          child: InkWell(
            onTap: () {
              navigateToUserLocation(context);
            },
            child: RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: S.of(context).yourLocation,
                    style: Theme.of(context)
                        .textTheme
                        .display2
                        .copyWith(fontSize: 13),
                  ),
                  WidgetSpan(
                    child: Icon(
                      Icons.keyboard_arrow_down,
                      size: 18,
                      color: appColor,
                    ),
                  ),
                  TextSpan(text: "\n"),
                  TextSpan(
                    text: 'Simmakal, Madurai',
                    style: Theme.of(context)
                        .textTheme
                        .display1
                        .copyWith(fontSize: 13),
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.favorite_border,
            ),
            onPressed: () {
              Navigator.of(context).pushNamed(
                favorites,
              );
            },
          ),
          horizontalSizedBox(),
        ],
      ),
      body: CustomScrollView(slivers: <Widget>[
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 15.0),
            child: Container(
              height: 150,
              child: ListView.builder(
                itemCount: _imagePath.length,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  return Container(
                    width: 168,
                    child: Image.asset(
                      _imagePath[index],
                      height: 200,
                      width: 230,
                    ),
                  );
                },
              ),
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.symmetric(
            vertical: 10.0,
          ),
          sliver: new SliverList(
            delegate: new SliverChildListDelegate([
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: _homeInfo.length,
                itemBuilder: (context, index) {
                  return showRestaurantList
                      ? FoodItems(
                          index: index,
                          imageTag: "home",
                        )
                      : showShimmer(context);
                },
              ),
            ]),
          ),
        ),
      ]),
    );
  }

// showing show closed info

}
