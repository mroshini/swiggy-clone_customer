import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/core/models/sample_models/manage_address_data.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/common_navigation.dart';

class ManageAddressScreen extends StatefulWidget {
  @override
  _ManageAddressScreenState createState() => _ManageAddressScreenState();
}

class _ManageAddressScreenState extends State<ManageAddressScreen> {
  var addressInfo = ManageAddressData().homeInfo;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        elevation: 1.0,
        title: Text(
          'My Address',
          style: Theme.of(context).textTheme.subhead,
        ),
      ),
      body: LayoutBuilder(
          builder: (BuildContext context, BoxConstraints viewportConstraints) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: viewportConstraints.maxHeight,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(
                      10.0,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        verticalSizedBox(),
                        GestureDetector(
                          onTap: () {
                            navigateToUserLocation(context);
                          },
                          child: Row(
                            children: <Widget>[
                              Icon(
                                Icons.add,
                                color: darkRed,
                              ),
                              horizontalSizedBox(),
                              Text(
                                'Add Address',
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      color: darkRed,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        divider(),
                        Text('Saved Addresses',
                            style: Theme.of(context).textTheme.display1),
                        verticalSizedBox(),
                        ListView.builder(
                          itemCount: addressInfo.length,
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) => Container(
                            height: 65.0,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Icon(
                                    addressInfo[index].iconValue,
                                    color: Colors.grey,
                                  ),
                                  horizontalSizedBox(),
                                  Flexible(
                                    flex: 4,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          addressInfo[index].lineOne,
                                          style: Theme.of(context)
                                              .textTheme
                                              .display1
                                              .copyWith(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w400,
                                              ),
                                        ),
                                        verticalSizedBoxFive(),
                                        Text(
                                          addressInfo[index].lineTwo,
                                          overflow: TextOverflow.ellipsis,
                                          style: Theme.of(context)
                                              .textTheme
                                              .display2
                                              .copyWith(
                                                  color: Colors.grey,
                                                  fontSize: 13),
                                        ),
                                      ],
                                    ),
                                  ),
                                  horizontalSizedBox(),
                                  InkWell(
                                    onTap: () {
                                      _showPopupMenu();
//                                      PopupMenuButton<int>(
//                                        itemBuilder: (context) => [
//                                          PopupMenuItem(
//                                            value: 1,
//                                            child: Text(
//                                              "Edit",
//                                              style: Theme.of(context)
//                                                  .textTheme
//                                                  .display2
//                                                  .copyWith(
//                                                      color: Colors.black),
//                                            ),
//                                          ),
//                                          PopupMenuItem(
//                                            value: 2,
//                                            child: Text(
//                                              "Delete",
//                                              style: Theme.of(context)
//                                                  .textTheme
//                                                  .display2
//                                                  .copyWith(
//                                                      color: Colors.black),
//                                            ),
//                                          ),
//                                        ],
//                                        // initialValue: 1,
//                                        onCanceled: () {
//                                          print("You have canceled the menu.");
//                                        },
//                                        onSelected: (value) {
//                                          print("value:$value");
//
//                                          switch (value) {
//                                            case 1:
//                                          }
//                                        },
//                                        icon: Icon(Icons.more_vert),
//                                      );
                                    },
                                    child: Icon(
                                      Icons.more_vert,
                                      color: Colors.grey,
                                      size: 15,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  void _showPopupMenu() async {
    await showMenu(
      context: context,
      position: RelativeRect.fromLTRB(150, 150, 150, 150),
      items: [
        PopupMenuItem<String>(
            child: Text(
              "Edit",
              style: Theme.of(context).textTheme.display2,
            ),
            value: '1'),
        PopupMenuItem<String>(
            child: Text(
              "Delete",
              style: Theme.of(context).textTheme.display2,
            ),
            value: '2'),
      ],
      elevation: 8.0,
    );
  }
}
