import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/buttons/form_submit_button.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class AddAddressScreen extends StatefulWidget {
  @override
  _AddAddressScreenState createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  TextEditingController completeAddressController;
  TextEditingController floorAddressController;
  TextEditingController landMarkAddressController;
  List<String> tag = ['Home', 'Work', 'Hotel', 'Other'];

  @override
  void initState() {
    super.initState();
    completeAddressController = TextEditingController();
    floorAddressController = TextEditingController();
    landMarkAddressController = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
        maxChildSize: 1.0,
        initialChildSize: .50,
        minChildSize: .50,
        builder: (context, scrollController) {
          return Scaffold(
            body: Container(
              child: SingleChildScrollView(
                controller: scrollController,
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        verticalSizedBox(),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                'Enter address details',
                                style: Theme.of(context).textTheme.subhead,
                              ),
                            ),
                            closeIconButton(context),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Text(
                                'Your Location',
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      color: Colors.grey,
                                      fontSize: 13,
                                    ),
                              ),
                              verticalSizedBox(),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Container(
                                        height: 20,
                                        width: 20,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border: Border.all(color: blue),
                                        ),
                                        child: Center(
                                          child: Icon(
                                            Icons.check,
                                            color: blue,
                                            size: 13,
                                          ),
                                        ),
                                      ),
                                      horizontalSizedBoxFive(),
                                      Text(
                                        'Enter address details',
                                        style: Theme.of(context)
                                            .textTheme
                                            .display1,
                                      ),
                                    ],
                                  ),
                                  Text(
                                    'Change',
                                    style: Theme.of(context)
                                        .textTheme
                                        .display1
                                        .copyWith(
                                          color: Colors.redAccent,
                                        ),
                                  ),
                                ],
                              ),
                              verticalSizedBox(),
                              enterAddressFields(completeAddressController,
                                  'Complete Address* '),
                              verticalSizedBox(),
                              enterAddressFields(
                                  floorAddressController, 'Floor (Optional) '),
                              verticalSizedBox(),
                              enterAddressFields(landMarkAddressController,
                                  'How to reach (Optional) '),
                              verticalSizedBoxTwenty(),
                              Text(
                                'Tag this location for later',
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      color: Colors.grey,
                                    ),
                              ),
                              Container(
                                height: 40,
                                child: ListView.builder(
                                    itemCount: tag.length,
                                    scrollDirection: Axis.horizontal,
                                    itemBuilder: (context, index) {
                                      return Padding(
                                        padding: const EdgeInsets.all(5.0),
                                        child: Align(
                                          child: Container(
                                            height: 17,
                                            width: 50,
                                            decoration: new BoxDecoration(
                                              border: Border.all(
                                                  color: Colors.grey,
                                                  width: 0.0),
                                              borderRadius: new BorderRadius
                                                      .all(
                                                  Radius.elliptical(50, 50)),
                                            ),
                                            child: Center(
                                              child: Text(
                                                tag[index],
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .display2
                                                    .copyWith(
                                                      fontSize: 12,
                                                      color: Colors.grey,
                                                    ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      );
                                    }),
                              ),
                              verticalSizedBox(),
                              FormSubmitButton(
                                title: 'Save Address',
                                buttonColor: Colors.grey[200],
                                onPressed: () {
                                  // Navigator.pushNamed(context, register);
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        });
  }

  TextField enterAddressFields(TextEditingController controller, String hint) =>
      TextField(
        onChanged: (value) {
          setState(() {
            //  showSearchList = true;
          });
        },
        controller: controller,
        style: Theme.of(context).textTheme.display2.copyWith(
              fontSize: 16,
            ),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: Theme.of(context)
              .textTheme
              .display2
              .copyWith(fontSize: 14, color: Colors.grey),
        ),
      );
}
