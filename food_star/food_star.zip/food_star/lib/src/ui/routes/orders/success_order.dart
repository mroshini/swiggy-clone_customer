import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/buttons/form_submit_button.dart';

class SuccessOrderScreen extends StatefulWidget {
  @override
  _SuccessOrderScreenState createState() => _SuccessOrderScreenState();
}

class _SuccessOrderScreenState extends State<SuccessOrderScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Positioned(
              top: MediaQuery.of(context).size.height / 5,
              left: MediaQuery.of(context).size.width / 5,
              child: Text('Your order placed successfully',
                  style: Theme.of(context).textTheme.headline),
            ),
            Align(
              alignment: Alignment.center,
              child: Container(
                height: 100,
                width: 100,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  shape: BoxShape.circle,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: appColor,
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.check,
                        size: 35,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: FormSubmitButton(
                  title: 'Track Order',
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.of(context).pushNamed(showLocationMapScreen,
                        arguments: 2 // show order success details below map
                        );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

//  LayoutBuilder(
//  builder: (BuildContext context, BoxConstraints viewportConstraints) {
//  return Padding(
//  padding: const EdgeInsets.all(10.0),
//  child: Column(
//  crossAxisAlignment: CrossAxisAlignment.center,
//  mainAxisAlignment: MainAxisAlignment.center,
//  children: <Widget>[
//  Expanded(
//  child: SingleChildScrollView(
//  child: ConstrainedBox(
//  constraints: BoxConstraints(
//  minHeight: viewportConstraints.maxHeight,
//  ),
//  child: Column(
//  crossAxisAlignment: CrossAxisAlignment.center,
//  mainAxisAlignment: MainAxisAlignment.start,
//  children: <Widget>[
//  Text(
//  'Congratulations!',
//  style: Theme.of(context).textTheme.subhead.copyWith(
//  color: appColor,
//  ),
//  ),
//  verticalSizedBox(),
//  Container(
//  height: 100,
//  width: 100,
//  decoration: BoxDecoration(
//  color: Colors.grey[100],
//  shape: BoxShape.circle,
//  ),
//  child: Padding(
//  padding: const EdgeInsets.all(15.0),
//  child: Container(
//  decoration: BoxDecoration(
//  color: appColor,
//  shape: BoxShape.circle,
//  ),
//  child: Center(
//  child: Icon(
//  Icons.check,
//  size: 35,
//  color: Colors.white,
//  ),
//  ),
//  ),
//  ),
//  ),
//  verticalSizedBox(),
//  FormSubmitButton(
//  title: 'Track Order',
//  onPressed: () {},
//  ),
//  ],
//  ),
//  ),
//  ),
//  ),
//  ]),
//  );
//  }),
}
