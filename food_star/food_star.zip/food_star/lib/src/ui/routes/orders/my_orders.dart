import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/sample_models/my_orders_data.dart';
import 'package:foodstar/src/core/models/sample_models/my_orders_model.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/colored_sized_box.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/restaurant_info_list_shimmer.dart';

class MyOrdersScreen extends StatefulWidget {
  @override
  _MyOrdersScreenState createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  final List<MyOrdersModel> myOrdersData = MyOrdersData().myOrders;
  bool _showShimmerView = false;

  @override
  void initState() {
    super.initState();
    // create a future delayed function that will change showInagewidget to true after 5 seconds

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _showShimmerView = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1.0,
        title: Text(
          S.of(context).myOrders,
          style: Theme.of(context).textTheme.subhead,
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: ListView.builder(
        itemCount: myOrdersData.length,
        itemBuilder: (context, index) {
          return _showShimmerView ? myOrdersList(index) : showShimmer(context);
        },
      ),
    );
  }

  Padding myOrdersList(int index) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5.0),
        child: Material(
          color: transparent,
          child: InkWell(
            onTap: () {
              Navigator.of(context).pushNamed(showLocationMapScreen,
                  arguments: 2 // show order success details below map
                  );
            },
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  verticalSizedBox(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10.0),
                          child: Image.asset(
                            myOrdersData[index].image,
                            height: 80.0,
                            width: 80.0,
                          ),
                        ),
                        horizontalSizedBox(),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  Container(
                                    height: 13,
                                    width: 13,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(
                                        2.0,
                                      ),
                                      border: Border.all(color: Colors.green),
                                    ),
                                    child: Center(
                                      child: Icon(
                                        Icons.fiber_manual_record,
                                        color: Colors.green,
                                        size: 10,
                                      ),
                                    ),
                                  ),
                                  horizontalSizedBoxFive(),
                                  Expanded(
                                    child: Text(myOrdersData[index].title,
                                        overflow: TextOverflow.ellipsis,
                                        style: Theme.of(context)
                                            .textTheme
                                            .display1),
                                  ),
                                ],
                              ),
                              verticalSizedBox(),
                              RichText(
                                text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "${myOrdersData[index].date}",
                                      style:
                                          Theme.of(context).textTheme.display2,
                                    ),
                                    TextSpan(
                                      text: " - ",
                                      style:
                                          Theme.of(context).textTheme.display2,
                                    ),
                                    TextSpan(
                                      text:
                                          "${myOrdersData[index].orderStatus}",
                                      style: Theme.of(context)
                                          .textTheme
                                          .display2
                                          .copyWith(
                                            fontSize: 14.0,
                                            color: darkRed,
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                              verticalSizedBox(),
                              Text(
                                "${myOrdersData[index].description}",
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.display2,
                              ),
                              verticalSizedBox(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  divider(),
                  verticalSizedBox(),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Text(
                                "${myOrdersData[index].totalItem} items | ${myOrdersData[index].price}",
                                style: Theme.of(context).textTheme.display3),
                            verticalSizedBox(),
                            Visibility(
                              visible: myOrdersData[index].availableStatus == 1
                                  ? false
                                  : true,
                              child: Text(
                                "${myOrdersData[index].totalItem} items are unavailable",
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      color: darkRed,
                                      fontWeight: FontWeight.w400,
                                    ),
                              ),
                            )
                          ],
                        ),
                        Container(
                          height: 30,
                          width: 100,
                          decoration: BoxDecoration(
                            color: myOrdersData[index].availableStatus == 1
                                ? appColor
                                : Colors.grey[400],
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          child: Center(
                            child: Text(
                              myOrdersData[index].availableStatus == 1
                                  ? S.of(context).orderAgain
                                  : 'Closed',
                              style:
                                  Theme.of(context).textTheme.display3.copyWith(
                                        color: white,
                                        fontWeight: FontWeight.w600,
                                      ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  verticalSizedBox(),
                  VerticalColoredSizedBox(),
                ],
              ),
            ),
          ),
        ),
      );
}
