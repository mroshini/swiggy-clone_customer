import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/constants/api_urls.dart';
import 'package:foodstar/src/constants/sharedpreference_keys.dart';
import 'package:foodstar/src/core/provider_viewmodels/auth/auth_view_model.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/routes/auth/login_screen.dart';
import 'package:foodstar/src/ui/routes/cart/cart.dart';
import 'package:foodstar/src/ui/routes/food_star_screen.dart';
import 'package:foodstar/src/ui/routes/my_account/profile.dart';
import 'package:foodstar/src/ui/routes/search/search_restaturants_list.dart';
import 'package:foodstar/src/ui/shared/track_order_info_card.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  int selectedIndexFromRoutedScreen;

  HomeScreen({this.selectedIndexFromRoutedScreen = 0});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _bottomNavMenuIndex = 0;
  SharedPreferences prefs;
  var loggedIn = false;

  final List<Widget> _bottomNavScreensIfNotLoggedIn = [
    FoodStarScreen(),
    SearchScreen(),
    CartScreen(
      showArrow: false,
    ),
    LoginScreen(),
  ];

  final List<Widget> _bottomNavScreensIfLoggedIn = [
    FoodStarScreen(),
    SearchScreen(),
    CartScreen(
      showArrow: false,
    ),
    MyAccountScreen(),
  ];

  @override
  void initState() {
    super.initState();
    setState(() {
      showLog("_HomeScreenState --${widget.selectedIndexFromRoutedScreen}");
      _bottomNavMenuIndex = widget.selectedIndexFromRoutedScreen ?? 0;
    });
  }

  initPref() async {
    if (prefs == null) prefs = await SharedPreferences.getInstance();
  }

  checkLoginOrNot() async {
    await initPref();
    loggedIn = prefs.getBool(SharedPreferenceKeys.isloggedIn) ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Consumer<AuthViewModel>(
        builder: (builder, auth, child) {
          return Scaffold(
            body: Stack(
              children: <Widget>[
                auth.authState == AuthState.authSkiped
                    ? _bottomNavScreensIfNotLoggedIn[_bottomNavMenuIndex ?? 0]
                    : _bottomNavScreensIfLoggedIn[_bottomNavMenuIndex ?? 0],
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Visibility(
                    visible: (_bottomNavMenuIndex == 2) ||
                            ((_bottomNavMenuIndex == 3 &&
                                    (auth.authState == AuthState.authSkiped)) ??
                                false)
                        ? false
                        : true,
                    child: TrackOrderInfoCard(),
                  ),
                ),
              ],
            ),
            bottomNavigationBar: BottomNavigationBar(
              unselectedItemColor: Colors.grey,
              selectedItemColor: appColor,
              onTap: onMenuClicked,
              // new
              type: BottomNavigationBarType.fixed,
              currentIndex: _bottomNavMenuIndex,
              // new
              items: [
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.stars,
                  ),
                  title: bottomNavText(
                    S.of(context).foodstar,
                    _bottomNavMenuIndex == 0 ? appColor : Colors.grey,
                  ),
                ),
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.search,
                  ),
                  title: bottomNavText(
                    S.of(context).search,
                    _bottomNavMenuIndex == 1 ? appColor : Colors.grey,
                  ),
                ),
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.shopping_basket,
                  ),
                  title: bottomNavText(
                    S.of(context).cart,
                    _bottomNavMenuIndex == 2 ? appColor : Colors.grey,
                  ),
                ),
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.person_outline,
                  ),
                  title: bottomNavText(
                    S.of(context).account,
                    _bottomNavMenuIndex == 3 ? appColor : Colors.grey,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Text bottomNavText(String title, Color textColor) => Text(
        title,
        style: Theme.of(context).textTheme.body1.copyWith(
              color: textColor,
            ),
      );

  int moveToNext() {
    return _bottomNavMenuIndex == 2 ? 0 : 1;
  }

  void onMenuClicked(int value) {
    setState(() {
      _bottomNavMenuIndex = value;
    });
  }
}
