import 'dart:math';

import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/core/provider_viewmodels/theme_changer.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:provider/provider.dart';

class SortFilterScreen extends StatefulWidget {
  @override
  _SortFilterScreenState createState() => _SortFilterScreenState();
}

class _SortFilterScreenState extends State<SortFilterScreen> {
  int selectedIndex = 4;

  List<String> bottomSheetDataList = [
    "Sort by",
    "Cuisine",
    "Rating",
    "Cost per person",
    "More filters",
  ];

  List<String> list1 = [
    "Popularity",
    "Rating: high to low",
    "Delivery time",
  ];

  List<String> list2 = [
    'Delivery time',
    'Cost: high to low',
    'Cose: low to high',
  ];

//  List<String> list3 = ['Scratch', 'Glass Broken', 'Too Old'];

  List<String> getSortFilterSubItems() {
    final random = Random();
    final lists = [list1, list2];
    return lists[random.nextInt(2)];
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.75,
        child: Scaffold(
          body: SafeArea(
            child: Container(
              margin: const EdgeInsets.symmetric(vertical: 10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  dragIcon(),
                  verticalSizedBox(),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(S.of(context).sortAndFilters,
                            style: Theme.of(context).textTheme.subhead),
                      ),
                      //closeIconButton(context),
                    ],
                  ),
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 10.0),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            flex: 1,
                            child: Container(
                              child: ListView.builder(
                                physics: NeverScrollableScrollPhysics(),
                                itemCount: bottomSheetDataList.length,
                                itemBuilder: (context, index) => InkWell(
                                  onTap: () {
                                    setState(() {
                                      selectedIndex = index;
                                    });
                                  },
                                  child: Consumer<ThemeManager>(
                                    builder: (builder, theme, child) {
                                      return Container(
                                        decoration: BoxDecoration(
                                          color: theme.darkMode
                                              ? (selectedIndex == index)
                                                  ? Colors.grey[500]
                                                  : Colors.grey[800]
                                              : (selectedIndex == index)
                                                  ? Colors.white
                                                  : Colors.grey[200],
                                          border: Border(
                                            left: BorderSide(
                                              color: theme.darkMode
                                                  ? (selectedIndex == index)
                                                      ? appColor
                                                      : Colors.grey[800]
                                                  : (selectedIndex == index)
                                                      ? appColor
                                                      : Colors.grey[200],
                                              width: 5,
                                            ),
                                          ),
                                        ),
                                        alignment: Alignment.centerLeft,
                                        height: 45.0,
                                        child: FilterListItemView(
                                          title: bottomSheetDataList[index],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: SubSortFilterView(
                              list: getSortFilterSubItems(),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Expanded(
                        flex: 3,
                        child: FlatButton(
                          child: Text(
                            S.of(context).clearAll,
                            style:
                                Theme.of(context).textTheme.display1.copyWith(
                                      color: Theme.of(context).accentColor,
                                    ),
                          ),
                          onPressed: () {},
                        ),
                      ),
                      Expanded(
                        flex: 4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: RaisedButton(
                            color: Theme.of(context).accentColor,
                            child: Text(
                              S.of(context).apply,
                              style: Theme.of(context)
                                  .textTheme
                                  .display1
                                  .copyWith(color: Colors.white),
                            ),
                            onPressed: () {},
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FilterListItemView extends StatelessWidget {
  final String title;

  const FilterListItemView({
    Key key,
    @required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Expanded(
          child: Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(title, style: Theme.of(context).textTheme.display2),
            ),
          ),
        ),
        Container(
          color: Colors.grey[300],
          height: 1.0,
        )
      ],
    );
  }
}

class SubSortFilterView extends StatefulWidget {
  final List<String> list;

  const SubSortFilterView({Key key, @required this.list}) : super(key: key);

  @override
  _SubSortFilterViewState createState() => _SubSortFilterViewState();
}

class _SubSortFilterViewState extends State<SubSortFilterView> {
  TextEditingController _sortEditingController;
  int _selectDeliveryOption = 0;

  @override
  void initState() {
    super.initState();
    _sortEditingController = TextEditingController();
  }

  changeDeliveryOption(int value) {
    setState(() {
      _selectDeliveryOption = value;
    });
  }

  @override
  void dispose() {
    super.dispose();
    _sortEditingController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
//          Container(
//            padding: const EdgeInsets.symmetric(horizontal: 8.0),
//            alignment: Alignment.centerLeft,
//            height: 40.0,
//            decoration: BoxDecoration(
//              borderRadius: BorderRadius.circular(20.0),
//              color: Colors.grey[200],
//            ),
//            child: Row(
//              crossAxisAlignment: CrossAxisAlignment.center,
//              mainAxisAlignment: MainAxisAlignment.start,
//              children: <Widget>[
//                Icon(Icons.search, size: 20.0),
//                Expanded(
//                  child: Container(
//                    margin: const EdgeInsets.only(
//                      left: 8.0,
//                      bottom: 5.0,
//                      right: 8.0,
//                    ),
//                    height: 40.0,
//                    child: TextField(
//                      controller: _sortEditingController,
//                      decoration: InputDecoration(
//                          border: InputBorder.none,
//                          hintStyle:
//                              Theme.of(context).textTheme.display2.copyWith(
//                                    fontSize: 13.0,
//                                    fontStyle: FontStyle.normal,
//                                  ),
//                          hintText: S.of(context).search),
//                      style: TextStyle(
//                        fontSize: 16.0,
//                      ),
//                    ),
//                  ),
//                )
//              ],
//            ),
//          ),
          verticalSizedBox(),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Top Picks',
                    style: Theme.of(context).textTheme.display2.copyWith(
                          color: Colors.grey,
                        ),
                  ),
                  Expanded(
                    flex: 2,
                    child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: widget.list.length,
                      itemBuilder: (context, index) => Ink(
                        child: Container(
                          child: Row(
                            children: <Widget>[
                              Flexible(
                                child: Radio(
                                  value: 1,
                                  groupValue: _selectDeliveryOption,
                                  activeColor: appColor,
                                  onChanged: changeDeliveryOption,
                                ),
                              ),
                              new Text(
                                widget.list[index],
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      fontStyle: FontStyle.normal,
                                      fontSize: 14,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
