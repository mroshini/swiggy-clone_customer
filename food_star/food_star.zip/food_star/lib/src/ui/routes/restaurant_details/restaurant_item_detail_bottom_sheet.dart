import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/core/models/arguments_model/imag_hero_tag_info.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class RestaurantItemDetailBottomSheetScreen extends StatefulWidget {
  final ImageHeroTagInfo imageInfo;

  RestaurantItemDetailBottomSheetScreen({this.imageInfo});

  @override
  _RestaurantItemDetailBottomSheetScreenState createState() =>
      _RestaurantItemDetailBottomSheetScreenState();
}

class _RestaurantItemDetailBottomSheetScreenState
    extends State<RestaurantItemDetailBottomSheetScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      child: Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 10.0,
          ),
          child: Column(
            children: <Widget>[
              dragIcon(),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(
                      20.0,
                    ),
                    child: Container(
                      height: MediaQuery.of(context).size.height,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Container(
                            height: 200,
                            width: MediaQuery.of(context).size.width,
                            child: Image.asset(
                              'assets/images/food3.jpg',
                              fit: BoxFit.cover,
                            ),
                          ),
                          verticalSizedBoxTwenty(),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    'Gago Gago Degun Telur',
                                    style: Theme.of(context).textTheme.display1,
                                  ),
                                  verticalSizedBox(),
                                  Text(
                                    'Cabe 1-4',
                                    style: Theme.of(context).textTheme.display3,
                                  ),
                                ],
                              ),
                              Container(
                                height: 30,
                                width: 80,
                                decoration: BoxDecoration(
                                  color: appColor,
                                  borderRadius: BorderRadius.circular(
                                    5.0,
                                  ),
                                ),
                                child: Center(
                                  child: Text(
                                    S.of(context).share,
                                    style: Theme.of(context)
                                        .textTheme
                                        .display3
                                        .copyWith(color: white),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      S.of(context).dishPrice,
                      style: Theme.of(context).textTheme.display1,
                    ),
                    verticalSizedBox(),
                    Text(
                      '50.000',
                      style: Theme.of(context).textTheme.display1,
                    ),
                  ],
                ),
              ),
              verticalSizedBox(),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: FlatButton(
                    color: appColor,
                    child: Text(
                      S.of(context).addToCart,
                      style: Theme.of(context).textTheme.display1.copyWith(
                            color: Colors.white,
                          ),
                    ),
                    onPressed: () {},
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
