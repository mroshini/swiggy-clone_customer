import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/core/provider_viewmodels/theme_changer.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/circle_profile_image.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:provider/provider.dart';

class RestaurantMapViewScreen extends StatefulWidget {
  @override
  _RestaurantMapViewScreenState createState() =>
      _RestaurantMapViewScreenState();
}

class _RestaurantMapViewScreenState extends State<RestaurantMapViewScreen> {
  int _selectedDate = 0;
  List<String> openingHoursList = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      maxChildSize: 1.0,
      initialChildSize: .50,
      minChildSize: .50,
      builder: (context, scrollController) {
        return Scaffold(
          body: Consumer<ThemeManager>(
            builder: (BuildContext context, ThemeManager theme, Widget child) {
              return Container(
                // padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  border: theme.darkMode
                      ? Border.all()
                      : Border.all(color: Colors.grey[200], width: .5),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: Container(
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.max,
                        children: <Widget>[
                          dragIcon(),
                          verticalSizedBox(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Flexible(
                                child: Text(
                                  'Indeonesia International Institute for Life Science',
                                  style: Theme.of(context).textTheme.subhead,
                                ),
                              ),
                              horizontalSizedBox(),
                              Container(
                                height: 30,
                                width: 30,
                                child: CircleAvatar(
                                  backgroundColor: darkGreen,
                                  child: Icon(
                                    Icons.call,
                                    color: white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          verticalSizedBox(),
                          Text(
                            'indeonesia International Institute for Life Science indeonesia International Institute for Life Science',
                            style: Theme.of(context).textTheme.display2,
                          ),
                          verticalSizedBox(),
                          divider(),
                          verticalSizedBox(),
                          Text(
                            'Rating',
                            style: Theme.of(context).textTheme.display1,
                          ),
                          verticalSizedBoxTwenty(),
                          Container(
                            child: Row(
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Icon(Icons.star, color: Colors.amber),
                                    horizontalSizedBox(),
                                    Text(
                                      '4.7',
                                      style:
                                          Theme.of(context).textTheme.headline,
                                    ),
                                    horizontalSizedBox(),
                                    Text(
                                      '1000+ rating',
                                      style:
                                          Theme.of(context).textTheme.display2,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          verticalSizedBoxTwenty(),
                          Padding(
                            padding: const EdgeInsets.all(
                              10.0,
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Flexible(
                                  child: buildRatingRow(
                                    image: 'assets/images/shop1.jpg',
                                    lineOne: 'Great taste',
                                    lineTwo: '1000+ rating',
                                    context: context,
                                  ),
                                ),
                                Flexible(
                                  child: buildRatingRow(
                                    image: 'assets/images/shop1.jpg',
                                    lineOne: 'Freshly made',
                                    lineTwo: '100+ rating',
                                    context: context,
                                  ),
                                ),
                                Flexible(
                                  child: buildRatingRow(
                                    image: 'assets/images/shop2.jpg',
                                    lineOne: 'Proper packaging',
                                    lineTwo: '100+ rating',
                                    context: context,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          verticalSizedBoxTwenty(),
                          Text(
                            S.of(context).openingHours,
                            style: Theme.of(context).textTheme.display1,
                          ),
                          verticalSizedBox(),
                          ListView.separated(
                            separatorBuilder: (context, index) => Divider(
                              color: Colors.grey[200],
                            ),
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context, index) {
                              return Material(
                                color: transparent,
                                child: InkWell(
                                  onTap: () {
                                    setState(() {
                                      _selectedDate = index;
                                    });
                                  },
                                  child: Row(
                                    children: <Widget>[
                                      IconButton(
                                        icon: Icon(
                                          Icons.date_range,
                                          color: theme.darkMode
                                              ? _selectedDate == index
                                                  ? Colors.white
                                                  : Colors.grey
                                              : _selectedDate == index
                                                  ? Colors.black
                                                  : Colors.black54,
                                        ),
                                        onPressed: () {},
                                      ),
                                      horizontalSizedBoxTwenty(),
                                      Flexible(
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Text(
                                                openingHoursList[index],
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .display1
                                                    .copyWith(
                                                      color: theme.darkMode
                                                          ? _selectedDate ==
                                                                  index
                                                              ? Colors.white
                                                              : Colors.grey
                                                          : _selectedDate ==
                                                                  index
                                                              ? Colors.black
                                                              : Colors.black54,
                                                      fontSize: 16,
                                                    ),
                                              ),
                                              verticalSizedBox(),
                                              Text(
                                                '07:30 - 20:00',
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .display2
                                                    .copyWith(
                                                      color: theme.darkMode
                                                          ? _selectedDate ==
                                                                  index
                                                              ? Colors.white
                                                              : Colors.grey
                                                          : _selectedDate ==
                                                                  index
                                                              ? Colors.black
                                                              : Colors.black54,
                                                    ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                            itemCount: openingHoursList.length,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Column buildRatingRow({
    String image,
    String lineOne,
    String lineTwo,
    BuildContext context,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          circleProfileImage(
            heightValue: 60,
            widthValue: 60,
            image: 'assets/images/shop1.jpg',
            mContext: context,
          ),
          verticalSizedBox(),
          Text(
            lineOne,
            style: Theme.of(context).textTheme.display1,
          ),
          verticalSizedBox(),
          Text(
            lineTwo,
            style: Theme.of(context).textTheme.display2,
          ),
        ],
      );
}
