import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class ChangeRestaurantScreen extends StatefulWidget {
  @override
  _ChangeRestaurantScreenState createState() => _ChangeRestaurantScreenState();
}

class _ChangeRestaurantScreenState extends State<ChangeRestaurantScreen> {
  TextEditingController addNoteController = TextEditingController();
  FocusNode addNoteTextFocus = new FocusNode();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 10.0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                verticalSizedBox(),
                closeIconButton(context),
                verticalSizedBox(),
                Flexible(
                  flex: 2,
                  child: Align(
                    alignment: Alignment.center,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                        30.0,
                      ),
                      child: Image.asset(
                        'assets/images/food3.jpg',
                        height: 130.0,
                        width: 150.0,
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                ),
                verticalSizedBoxTwenty(),
                Flexible(
                  child: Text(S.of(context).wantToChangeRestaurant,
                      style: Theme.of(context).textTheme.subhead),
                ),
                verticalSizedBox(),
                Flexible(
                  child: Text(S.of(context).changeRestaurantBodyContent,
                      style: Theme.of(context).textTheme.body2),
                ),
                verticalSizedBoxTwenty(),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Expanded(
                        flex: 4,
                        child: OutlineButton(
                          child: Text(
                            S.of(context).cancel,
                            style: Theme.of(context)
                                .textTheme
                                .display3
                                .copyWith(color: appColor, fontSize: 13),
                          ),
                          color: appColor,
                          onPressed: () {},
                          highlightedBorderColor: darkGreen,
                          shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(
                              8.0,
                            ),
                          ),
                        ),
                      ),
                      verticalSizedBoxTwenty(),
                      Expanded(
                        flex: 4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: RaisedButton(
                            color: appColor,
                            child: Text(
                              S.of(context).sureGoAhead,
                              style: Theme.of(context)
                                  .textTheme
                                  .display3
                                  .copyWith(color: white, fontSize: 13),
                            ),
                            onPressed: () {},
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
