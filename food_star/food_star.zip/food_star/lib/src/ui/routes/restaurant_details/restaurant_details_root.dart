import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/api_urls.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/arguments_model/imag_hero_tag_info.dart';
import 'package:foodstar/src/core/models/sample_models/home_model_data.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_data.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_model.dart';
import 'package:foodstar/src/core/provider_viewmodels/theme_changer.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/routes/restaurant_details/change_restaurant_bottom_sheet.dart';
import 'package:foodstar/src/ui/shared/cart_info_card.dart';
import 'package:foodstar/src/ui/shared/colored_sized_box.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/restaurant_item_widget.dart';
import 'package:foodstar/src/ui/shared/shop_closed_widget.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/dialog_helper.dart';
import 'package:foodstar/src/utils/search_restaurant_menu.dart';
import 'package:provider/provider.dart';

class RestaurantDetailScreen extends StatefulWidget {
  final ImageHeroTagInfo imageInfo;

  RestaurantDetailScreen({this.imageInfo});

  @override
  _RestaurantDetailScreenState createState() => _RestaurantDetailScreenState();
}

class _RestaurantDetailScreenState extends State<RestaurantDetailScreen> {
  final List<RestaurantItemModel> restaurantItemInfo =
      RestaurantItemData().restaurantItemInfo;
  var favoriteIndex = 0;
  var shopStatus = 1;
  bool showIcon = false;
  var _imagePath = HomeModelData().imagePath;
  ScrollController _scrollController;
  bool detectScrollState;
  final restaurantMenu = [
    'French fries French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
  ];

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
//    _scrollController = ScrollController(initialScrollOffset: 50.0);
    _scrollController.addListener(() => setState(() {}));

    showLog('${widget.imageInfo}');
    listenScrollController();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: <Widget>[
          Consumer<ThemeManager>(
            builder: (BuildContext context, ThemeManager theme, Widget child) {
              return NestedScrollView(
                controller: _scrollController,
                headerSliverBuilder:
                    (BuildContext context, bool innerBoxIsScrolled) {
                  return <Widget>[
                    SliverAppBar(
                      leading: IconButton(
                        icon: Icon(Icons.arrow_back),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      iconTheme: IconThemeData(
                          color: listenScrollController()
                              ? theme.darkMode ? Colors.black : Colors.white
                              : Colors.black),
                      backgroundColor:
                          theme.darkMode ? Colors.black38 : Colors.white,
                      expandedHeight: 230.0,
                      floating: false,
                      pinned: true,
                      actions: showAppBarIcon(theme),
                      title: Visibility(
                        visible: listenScrollController() ? false : true,
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: 'Neo Restaurant, Chennai',
                                style: Theme.of(context)
                                    .textTheme
                                    .display1
                                    .copyWith(fontSize: 10),
                              ),
                              TextSpan(text: "\n"),
                              WidgetSpan(
                                child: Icon(
                                  Icons.access_time,
                                  size: 15,
                                  color: darkRed,
                                ),
                              ),
                              TextSpan(text: " "),
                              TextSpan(
                                text: 'Closed',
                                style: Theme.of(context)
                                    .textTheme
                                    .display1
                                    .copyWith(fontSize: 9),
                              ),
                            ],
                          ),
                        ),
                      ),
                      flexibleSpace: FlexibleSpaceBar(
                        background: Hero(
                          tag: widget.imageInfo.tag,
                          child: Image.asset(
                            widget.imageInfo.image,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                    ),
                  ];
                },
                body: LayoutBuilder(
                  builder: (BuildContext context,
                      BoxConstraints viewportConstraints) {
                    return Stack(
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            Expanded(
                              child: SingleChildScrollView(
                                child: Container(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Container(
                                        child: Padding(
                                          padding: const EdgeInsets.all(15.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: <Widget>[
                                              verticalSizedBoxTwenty(),
                                              Text(
                                                  "kfdjflksdjfljsdlfjdslfklsdkfl;sdkdfkjndskjfnkdnfdfsafafl;dks",
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .subhead),
                                              verticalSizedBox(),
                                              Text(
                                                "kfdjflksdjfl, coffee",
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .display2,
                                              ),
                                              verticalSizedBox(),
                                              Row(
                                                children: <Widget>[
                                                  Container(
                                                    color: Colors.red,
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              5.0),
                                                      child: Text(
                                                        "kfdjflksdjfl, coffee",
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .display2
                                                            .copyWith(
                                                              color: white,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                                  horizontalSizedBox(),
                                                  Container(
                                                    color: Colors.blue,
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.all(
                                                              5.0),
                                                      child: Text(
                                                        "kfdjflksdjfl, coffee",
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .display2
                                                            .copyWith(
                                                              color: white,
                                                            ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              verticalSizedBox(),
                                              divider(),
                                              verticalSizedBox(),
                                              Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceAround,
                                                children: <Widget>[
                                                  Column(
                                                    children: <Widget>[
                                                      Row(
                                                        children: <Widget>[
                                                          Icon(Icons.star,
                                                              color:
                                                                  Colors.amber),
                                                          horizontalSizedBox(),
                                                          Text('4.7',
                                                              style: Theme.of(
                                                                      context)
                                                                  .textTheme
                                                                  .display1),
                                                          horizontalSizedBox(),
                                                          Icon(
                                                              Icons
                                                                  .keyboard_arrow_down,
                                                              color:
                                                                  Colors.red),
                                                        ],
                                                      ),
                                                      verticalSizedBox(),
                                                      Text(
                                                        '1000+ rating',
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .display2,
                                                      ),
                                                    ],
                                                  ),
                                                  horizontalSizedBox(),
                                                  Column(
                                                    children: <Widget>[
                                                      Row(
                                                        children: <Widget>[
                                                          Icon(
                                                            Icons.location_on,
                                                          ),
                                                          horizontalSizedBox(),
                                                          Text(
                                                            '0.33 km',
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .display1,
                                                          ),
                                                        ],
                                                      ),
                                                      verticalSizedBox(),
                                                      Text(
                                                        '20 min',
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .display2,
                                                      ),
                                                    ],
                                                  ),
                                                  horizontalSizedBox(),
                                                  Column(
                                                    children: <Widget>[
                                                      SizedBox(
                                                        height: 5.0,
                                                      ),
                                                      Row(
                                                        children: <Widget>[
                                                          Text(
                                                            r"$",
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .display1
                                                                .copyWith(
                                                                    color: theme.darkMode
                                                                        ? Colors
                                                                            .grey
                                                                        : Colors
                                                                            .black),
                                                          ),
                                                          Text(
                                                            r"$",
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .display1
                                                                .copyWith(
                                                                    color: theme
                                                                            .darkMode
                                                                        ? Colors.grey[
                                                                            100]
                                                                        : Colors
                                                                            .black45),
                                                          ),
                                                          Text(
                                                            r"$",
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .display1
                                                                .copyWith(
                                                                    color: theme
                                                                            .darkMode
                                                                        ? Colors.grey[
                                                                            100]
                                                                        : Colors
                                                                            .black45),
                                                          ),
                                                          Text(
                                                            r"$",
                                                            style: Theme.of(
                                                                    context)
                                                                .textTheme
                                                                .display1
                                                                .copyWith(
                                                                    color: theme
                                                                            .darkMode
                                                                        ? Colors.grey[
                                                                            100]
                                                                        : Colors
                                                                            .black45),
                                                          )
                                                        ],
                                                      ),
                                                      verticalSizedBox(),
                                                      Text(
                                                        '40k - 100k',
                                                        style: Theme.of(context)
                                                            .textTheme
                                                            .display2,
                                                      ),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                              verticalSizedBox(),
                                              divider(),
                                              verticalSizedBox(),
                                              Row(
                                                children: <Widget>[
                                                  Icon(
                                                    Icons.access_time,
                                                    color: Colors.red[800],
                                                  ),
                                                  horizontalSizedBox(),
                                                  shopClosedWidget(context),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      VerticalColoredSizedBox(),
                                      Container(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 15.0,
                                            vertical: 20.0,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              verticalSizedBox(),
                                              Text(
                                                "Available Promos",
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .display1,
                                              ),
                                              ListView.builder(
                                                shrinkWrap: true,
                                                itemCount: 2,
                                                physics:
                                                    NeverScrollableScrollPhysics(),
                                                itemBuilder: (context, index) {
                                                  return Padding(
                                                    padding: const EdgeInsets
                                                            .symmetric(
                                                        vertical: 5.0),
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceBetween,
                                                      children: <Widget>[
                                                        Flexible(
                                                          child: Row(
                                                            children: <Widget>[
                                                              Icon(
                                                                Icons.note,
                                                                color: Colors
                                                                    .blue[700],
                                                              ),
                                                              horizontalSizedBox(),
                                                              Flexible(
                                                                child: Text(
                                                                  '12k, food discount, minimum order,12k, food discount, minimum order',
                                                                  overflow:
                                                                      TextOverflow
                                                                          .ellipsis,
                                                                  style: Theme.of(
                                                                          context)
                                                                      .textTheme
                                                                      .display2,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        horizontalSizedBox(),
                                                        Icon(
                                                          Icons
                                                              .keyboard_arrow_right,
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      VerticalColoredSizedBox(),
                                      ListView.builder(
                                        physics: NeverScrollableScrollPhysics(),
                                        shrinkWrap: true,
                                        itemCount: 3,
                                        itemBuilder: (context, index) {
                                          return Padding(
                                            padding: const EdgeInsets.all(5.0),
                                            child: Container(
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                  horizontal: 15.0,
                                                ),
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      "Ramzan Specials",
                                                      style: TextStyle(
                                                          fontSize: 15.0,
                                                          fontWeight:
                                                              FontWeight.bold),
                                                    ),
                                                    verticalSizedBox(),
                                                    divider(),
                                                    verticalSizedBox(),
                                                    ListView.separated(
                                                      separatorBuilder:
                                                          (context, index) =>
                                                              Divider(
                                                        color: Colors.grey[200],
                                                      ),
                                                      shrinkWrap: true,
                                                      itemCount:
                                                          restaurantItemInfo
                                                              .length,
                                                      physics:
                                                          NeverScrollableScrollPhysics(),
                                                      itemBuilder:
                                                          (context, index) {
                                                        return Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                      .symmetric(
                                                                  vertical:
                                                                      8.0),
                                                          child: RestaurantItem(
                                                            itemInfo:
                                                                restaurantItemInfo,
                                                            index: index,
//                                                        imageTag:
//                                                            "restaurant_item",
                                                          ),
                                                        );
                                                      },
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Positioned(
                          bottom: 10.0,
                          left: 10.0,
                          right: 10.0,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  GestureDetector(
                                    onTap: () {
                                      // navigateToHome(context);
                                      DialogHelper.menuPopup(context);
                                    },
                                    child: Image.asset(
                                      'assets/images/menu.png',
                                      height: 50.0,
                                      width: 50.0,
                                    ),
                                  ),
                                  verticalSizedBox(),
                                  CartInfoCard(),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              );
            },
          ),
          _buildMapButton(),
        ],
      ),
    );
  }

  bool listenScrollController() {
    final double defaultTopMargin = 200.0 - 4.0;

    //pixels from top where scaling should start

    final double scaleStart = 96.0;
    //pixels from top where scaling should end

    final double scaleEnd = scaleStart / 2;

    double top = defaultTopMargin;

    double scale = 1.0;

    if (_scrollController.hasClients) {
      double offset = _scrollController.offset;
      top -= offset;
      if (offset < defaultTopMargin - scaleStart) {
        //offset small => don't scale down
        showIcon = true;
      } else if (offset < defaultTopMargin - scaleEnd) {
        //offset between scaleStart and scaleEnd => scale down
        showIcon = true;
      } else {
        //offset passed scaleEnd => hide fab
        showIcon = false;
      }
    }

    return showIcon;
  }

  List<Widget> showAppBarIcon(ThemeManager themeManager) {
    return listenScrollController()
        ? <Widget>[
            CircleAvatar(
              backgroundColor: Colors.black26,
              child: GestureDetector(
                onTap: () {
                  showSearchResults(context);
                },
                child: Icon(
                  Icons.search,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
            horizontalSizedBoxTwenty(),
            GestureDetector(
              onTap: () {
                openBottomSheet(context, ChangeRestaurantScreen());
              },
              child: CircleAvatar(
                backgroundColor: Colors.black26,
                child: Icon(
                  Icons.subdirectory_arrow_right,
                  color: Colors.white,
                  size: 30,
                ),
              ),
            ),
            horizontalSizedBox(),
          ]
        : <Widget>[
            IconButton(
              icon: Icon(
                Icons.search,
                color: themeManager.darkMode ? Colors.white : Colors.black,
              ),
              onPressed: () {
                showSearchResults(context);
              },
            ),
            horizontalSizedBoxTwenty(),
            GestureDetector(
              onTap: () {
                openBottomSheet(context, ChangeRestaurantScreen());
              },
              child: Icon(
                Icons.subdirectory_arrow_right,
                color: themeManager.darkMode ? Colors.white : Colors.black,
              ),
            ),
            horizontalSizedBox(),
          ];
  }

  showSearchResults(BuildContext context) => showSearch(
        context: context,
        delegate: SearchRestaurantMenu(),
      );

  Positioned _buildMapButton() {
    //starting fab position

    final double defaultTopMargin = 200.0 - 4.0;
    //pixels from top where scaling should start

    final double scaleStart = 96.0;
    //pixels from top where scaling should end

    final double scaleEnd = scaleStart / 2;

    double top = defaultTopMargin;

    double scale = 1.0;

    if (_scrollController.hasClients) {
      double offset = _scrollController.offset;
      top -= offset;
      if (offset < defaultTopMargin - scaleStart) {
        //offset small => don't scale down
        scale = 1.0;
      } else if (offset < defaultTopMargin - scaleEnd) {
        //offset between scaleStart and scaleEnd => scale down
        scale = (defaultTopMargin - scaleEnd - offset) / scaleEnd;
      } else {
        //offset passed scaleEnd => hide fab
        scale = 0.0;
      }
    }

    return Positioned(
      top: top,
      right: 16.0,
      child: GestureDetector(
        onTap: () {
          Navigator.of(context).pushNamed(showLocationMapScreen,
              arguments: 1 // show restaurant  rating details below map
              );
        },
        child: new Transform(
          transform: new Matrix4.identity()..scale(scale),
          alignment: Alignment.center,
          child: Card(
            elevation: 20.0,
            child: Image.asset(
              'assets/images/map.png',
              height: 70,
              width: 70,
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}
