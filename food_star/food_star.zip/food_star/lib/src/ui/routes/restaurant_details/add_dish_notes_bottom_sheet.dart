import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class AddDishNotesScreen extends StatefulWidget {
  @override
  _AddDishNotesScreenState createState() => _AddDishNotesScreenState();
}

class _AddDishNotesScreenState extends State<AddDishNotesScreen> {
  TextEditingController addNoteController = TextEditingController();
  FocusNode addNoteTextFocus = new FocusNode();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      child: Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    dragIcon(),
                    verticalSizedBox(),
                    Text(S.of(context).addNotesToYourDish,
                        style: Theme.of(context).textTheme.subhead),
                    verticalSizedBox(),
                    divider(),
                    verticalSizedBox(),
                    Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                      ),
                      width: MediaQuery.of(context).size.width,
                      child: TextField(
                        // focusNode: addNoteTextFocus,
                        onChanged: (value) {
                          // filterSearchResults(value);
                        },
                        controller: addNoteController,
                        style: TextStyle(
                          fontStyle: FontStyle.normal,
                          color: Colors.black,
                          fontSize: 16,
                        ),
                        maxLength: 200,
                        decoration: InputDecoration(
                          hintText: S.of(context).exampleMakeMyFoodSpicy,
                          hintStyle:
                              Theme.of(context).textTheme.display2.copyWith(
                                    color: Colors.grey,
                                  ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                          child: Container(
                            height: 30,
                            width: 70,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            child: Center(
                              child: Text(
                                S.of(context).done,
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                      color: white,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
