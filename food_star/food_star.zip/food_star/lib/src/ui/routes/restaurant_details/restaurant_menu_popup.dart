import 'package:flutter/material.dart';

class RestaurantMenuPopUpScreen extends StatefulWidget {
  @override
  _RestaurantMenuPopUpScreenState createState() =>
      _RestaurantMenuPopUpScreenState();
}

class _RestaurantMenuPopUpScreenState extends State<RestaurantMenuPopUpScreen> {
  final restaurantMenu = [
    'French fries French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
    'French fries French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
    'French fries',
    'Special pizza',
    'Promos for you',
  ];

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Scaffold(
        body: ListView.separated(
          itemCount: restaurantMenu.length,
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                Navigator.pop(
                  context,
                );
              },
              child: Container(
                child: Padding(
                  padding: const EdgeInsets.all(
                    10.0,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text(
                        restaurantMenu[index],
                        style: Theme.of(context).textTheme.display3.copyWith(),
                      ),
                      Text(
                        '$index',
                        style: Theme.of(context).textTheme.display2.copyWith(),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return Divider(
              color: Colors.grey[200],
            );
          },
        ),
      ),
    );
//    return AlertDialog(
//      content: ListView.separated(
//        shrinkWrap: true,
//        itemCount: restaurantMenu.length,
//        itemBuilder: (context, index) {
//          return Container(
//            child: Padding(
//              padding: const EdgeInsets.all(10.0),
//              child: Row(
//                crossAxisAlignment: CrossAxisAlignment.start,
//                mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                children: <Widget>[
//                  Text(
//                    restaurantMenu[index],
//                    style: Theme.of(context).textTheme.display3.copyWith(
//                          color: Colors.black,
//                        ),
//                  ),
//                  Text(
//                    '$index',
//                    style: Theme.of(context).textTheme.display2.copyWith(
//                          color: Colors.black,
//                        ),
//                  ),
//                ],
//              ),
//            ),
//          );
//        },
//        separatorBuilder: (BuildContext context, int index) {
//          return Divider(
//            color: Colors.grey[200],
//          );
//        },
//      ),
//    );
  }
}
