import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_data.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_model.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/colored_sized_box.dart';
import 'package:foodstar/src/ui/shared/restaurant_item_widget.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/cart_and_favorites_shimmer.dart';

class FavoritesScreen extends StatefulWidget {
  @override
  _FavoritesScreenState createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final List<RestaurantItemModel> mFavouriteItem =
      RestaurantItemData().favouriteItem;
  bool _showShimmerView = false;

  @override
  void initState() {
    super.initState();
    // create a future delayed function that will change showInagewidget to true after 5 seconds

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _showShimmerView = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 1.0,
        title: Text(
          S.of(context).myFavourites,
          style: Theme.of(context).textTheme.subhead,
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: SafeArea(
        child: ListView.builder(
          itemCount: 3,
          itemBuilder: (context, index) {
            return _showShimmerView
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10.0),
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          verticalSizedBoxTwenty(),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Text(
                              'Ayam Cobek, jontor, Cempaka puthih',
                              style:
                                  Theme.of(context).textTheme.display3.copyWith(
                                        fontSize: 15,
                                      ),
                            ),
                          ),
                          verticalSizedBox(),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Text(
                              '3029 km -JI. Complete putih Timur No. 67D, Cempaka Putih, jakarta,',
                              style:
                                  Theme.of(context).textTheme.display2.copyWith(
                                        fontSize: 15,
                                      ),
                            ),
                          ),
                          verticalSizedBoxTwenty(),
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Row(
                              children: <Widget>[
                                Container(
                                  height: 30,
                                  width: 80,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5.0),
                                    border:
                                        Border.all(color: Colors.green[700]),
                                  ),
                                  child: Center(
                                    child: Text(
                                      S.of(context).open,
                                      style: Theme.of(context)
                                          .textTheme
                                          .display3
                                          .copyWith(
                                            color: Colors.green[700],
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                  ),
                                ),
                                horizontalSizedBox(),
                                Text(
                                  '24 hours',
                                  style: Theme.of(context)
                                      .textTheme
                                      .display2
                                      .copyWith(
                                        fontSize: 15,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          verticalSizedBoxTwenty(),
                          Stack(
                            children: <Widget>[
                              Container(
                                height: 180,
                                width: MediaQuery.of(context).size.width,
                                child: Image.asset(
                                  mFavouriteItem[index].image,
                                  fit: BoxFit.cover,
                                ),
                              ),
                              Positioned(
                                top: 140.0,
                                left: MediaQuery.of(context).size.width / 2.2,
                                child: Container(
                                  height: 25,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5.0),
                                    color: Colors.blue[500],
                                  ),
                                  child: Center(
                                    child: RichText(
                                      text: TextSpan(
                                        children: [
                                          TextSpan(
                                            text: ' ',
                                          ),
                                          WidgetSpan(
                                            child: Icon(
                                              Icons.account_balance_wallet,
                                              size: 18,
                                              color: white,
                                            ),
                                          ),
                                          TextSpan(
                                            text: ' gopay',
                                            style: Theme.of(context)
                                                .textTheme
                                                .display3
                                                .copyWith(
                                                    color: white,
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.bold),
                                          ),
                                          TextSpan(
                                            text: ' DELIVERY PROMO ',
                                            style: Theme.of(context)
                                                .textTheme
                                                .display2
                                                .copyWith(
                                                    color: white,
                                                    fontSize: 12,
                                                    fontStyle:
                                                        FontStyle.normal),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          verticalSizedBox(),
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: ListView.separated(
                              separatorBuilder: (context, index) => Divider(
                                color: Colors.grey[200],
                              ),
                              shrinkWrap: true,
                              itemCount: mFavouriteItem.length,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 8.0),
                                  child: RestaurantItem(
                                    itemInfo: mFavouriteItem,
                                    index: index,
                                    addWithPlusIcon: false,
                                  ),
                                );
                              },
                            ),
                          ),
                          VerticalColoredSizedBox(),
                        ],
                      ),
                    ),
                  )
                : showCartAndFavoritesShimmer(context);
          },
        ),
      ),
    );
  }
}
