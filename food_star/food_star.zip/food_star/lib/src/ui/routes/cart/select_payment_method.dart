import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class SelectPaymentScreen extends StatefulWidget {
  @override
  _SelectPaymentScreenState createState() => _SelectPaymentScreenState();
}

class _SelectPaymentScreenState extends State<SelectPaymentScreen> {
  TextEditingController addNoteController = TextEditingController();
  FocusNode addNoteTextFocus = new FocusNode();

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: 10.0,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            verticalSizedBox(),
            closeIconButton(context),
            verticalSizedBox(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Text(
                S.of(context).selectPaymentMethod,
                style: Theme.of(context).textTheme.subhead,
              ),
            ),
            verticalSizedBoxTwenty(),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                horizontalSizedBox(),
                Row(
                  children: <Widget>[
                    Container(
                      height: 30,
                      width: 30,
                      child: CircleAvatar(
                        backgroundColor: Colors.blue,
                        child: Icon(
                          Icons.account_balance_wallet,
                          color: white,
                          size: 20.0,
                        ),
                      ),
                    ),
                    horizontalSizedBox(),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Online Payment",
                          style: Theme.of(context).textTheme.display3.copyWith(
                              fontSize: 15.0, fontWeight: FontWeight.w600),
//                          style: TextStyle(
//                              fontSize: 16.0,
//                              color: Colors.black,
//                              fontWeight: FontWeight.bold),
                        ),
                        verticalSizedBox(),
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: S.of(context).yourBalance,
                                style: Theme.of(context).textTheme.display2,
                              ),
                              TextSpan(
                                text: "  0 ",
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                      color: darkRed,
                                      fontWeight: FontWeight.w600,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                Spacer(),
                OutlineButton(
                  splashColor: Colors.grey,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  highlightElevation: 0,
                  borderSide: BorderSide(color: appColor),
                  child: Text(
                    'Pay now',
                    style: Theme.of(context).textTheme.display3.copyWith(
                          color: appColor,
                          fontSize: 13.0,
                        ),
                  ),
                  onPressed: () {},
                ),
              ],
            ),
            verticalSizedBox(),
            divider(),
            verticalSizedBoxTwenty(),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    horizontalSizedBox(),
                    Icon(
                      Icons.note_add,
                      color: appColor,
                      size: 25.0,
                    ),
                    horizontalSizedBox(),
                    Text(
                      S.of(context).cash,
                      style: Theme.of(context).textTheme.display3.copyWith(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                          ),
                    )
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      S.of(context).delivery,
                      style: Theme.of(context).textTheme.display3.copyWith(
                            fontWeight: FontWeight.w600,
                            fontSize: 16.0,
                          ),
                    ),
                    horizontalSizedBox(),
                    Text(
                      "6,000",
                      style: Theme.of(context).textTheme.display3.copyWith(
                          fontSize: 16.0, fontWeight: FontWeight.w600),
                    ),
                    horizontalSizedBox(),
                  ],
                ),
              ],
            ),
            verticalSizedBoxTwenty(),
          ],
        ),
      ),
    );
  }
}
