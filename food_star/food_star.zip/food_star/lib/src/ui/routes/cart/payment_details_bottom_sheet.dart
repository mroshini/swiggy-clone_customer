import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/doted_divider.dart';

class PaymentDetailScreen extends StatefulWidget {
  @override
  _PaymentDetailScreenState createState() => _PaymentDetailScreenState();
}

class _PaymentDetailScreenState extends State<PaymentDetailScreen> {
  TextEditingController addNoteController = TextEditingController();
  FocusNode addNoteTextFocus = new FocusNode();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      child: Scaffold(
        resizeToAvoidBottomPadding: false,
        body: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 10.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    closeIconButton(context),
                    paymentDetailRow(
                      textValueOne: S.of(context).paymentDetails,
                      styleOne: Theme.of(context)
                          .textTheme
                          .subhead
                          .copyWith(fontSize: 16),
                    ),
                    verticalSizedBoxFive(),
                    divider(),
                    Column(
                      children: <Widget>[
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).priceEstimated,
                          styleOne: Theme.of(context).textTheme.display2,
                          textValueTwo: '17.500',
                          styleTwo: Theme.of(context).textTheme.display2,
                        ),
                        verticalSizedBoxFive(),
                        DotedDivider(
                          color: Colors.grey[300],
                        ),
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).convenienceFee,
                          styleOne: Theme.of(context).textTheme.display2,
                          textValueTwo: S.of(context).free,
                          styleTwo: Theme.of(context).textTheme.display2,
                        ),
                        verticalSizedBoxFive(),
                        DotedDivider(
                          color: Colors.grey[300],
                        ),
                        verticalSizedBoxFive(),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Text(
                              S.of(context).deliveryFee,
                              style: Theme.of(context).textTheme.display2,
                            ),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: '( 15,000 - ',
                                    style: Theme.of(context).textTheme.display2,
                                  ),
                                  TextSpan(
                                    text: "6,000 ) ",
                                    style: Theme.of(context)
                                        .textTheme
                                        .display2
                                        .copyWith(color: blue),
                                  ),
                                  TextSpan(
                                    text: '9,000',
                                    style: Theme.of(context).textTheme.display2,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        verticalSizedBox(),
                        DotedDivider(
                          color: Colors.grey[300],
                        ),
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).restoOffer,
                          styleOne: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                          textValueTwo: '-12.000',
                          styleTwo: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                        ),
                        verticalSizedBoxFive(),
                        DotedDivider(
                          color: Colors.grey[300],
                        ),
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).gofoodPartnerDiscount,
                          styleOne: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                          textValueTwo: '-6.000',
                          styleTwo: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                        ),
                        verticalSizedBoxFive(),
                        DotedDivider(
                          color: Colors.grey[300],
                        ),
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).promo,
                          styleOne: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                          textValueTwo: '-157.000',
                          styleTwo: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(color: blue),
                        ),
                        verticalSizedBoxFive(),
                        divider(),
                        verticalSizedBoxFive(),
                        paymentDetailRow(
                          textValueOne: S.of(context).totalPayment,
                          styleOne:
                              Theme.of(context).textTheme.display2.copyWith(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                          textValueTwo: "675.000",
                          styleTwo:
                              Theme.of(context).textTheme.display2.copyWith(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
                    verticalSizedBoxFive(),
                    divider(),
                    verticalSizedBoxFive(),
                    Expanded(
                      child: Column(
                        children: <Widget>[
                          Text(
                            S
                                .of(context)
                                .disclaimerFinalPriceMayChangeSlightlyIfTheRestaurantHas,
                            style: Theme.of(context)
                                .textTheme
                                .body2
                                .copyWith(fontSize: 12),
                          ),
                          verticalSizedBoxFive(),
                          Text(
                              S
                                  .of(context)
                                  .forYourEasePleaseMakeSureYourOrderDoesntNeed,
                              style: Theme.of(context)
                                  .textTheme
                                  .body2
                                  .copyWith(fontSize: 12)),
                          verticalSizedBoxFive(),
                          DotedDivider(
                            color: Colors.grey[300],
                          ),
                          verticalSizedBoxFive(),
                          Text(
                            S
                                .of(context)
                                .convenienceFeeIsAFeeForOrderingThroughGofood,
                            style: Theme.of(context)
                                .textTheme
                                .body2
                                .copyWith(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
