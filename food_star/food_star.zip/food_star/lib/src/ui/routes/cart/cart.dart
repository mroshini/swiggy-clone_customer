import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/generated/l10n.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_data.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_model.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/routes/cart/payment_details_bottom_sheet.dart';
import 'package:foodstar/src/ui/routes/cart/select_payment_method.dart';
import 'package:foodstar/src/ui/shared/colored_sized_box.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/restaurant_item_widget.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/common_navigation.dart';

class CartScreen extends StatefulWidget {
  bool showArrow;

  CartScreen({this.showArrow});

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final List<RestaurantItemModel> restaurantItemInfo =
      RestaurantItemData().cartItem;
  var favoriteClicked = false;
  var favoriteIndex = 0;
  bool _showShimmerView = false;
  var _imagePath = [
    "assets/images/food2.jpg",
    "assets/images/food1.jpg",
    "assets/images/food3.jpg",
    "assets/images/food1.jpg",
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      // backgroundColor: Colors.grey[200],
      appBar: AppBar(
        automaticallyImplyLeading: widget.showArrow ? true : false,
        elevation: 1.0,
        title: Text(
          "Nesi, favlovers",
          style: Theme.of(context).textTheme.subhead,
        ),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints viewportConstraints) {
          return Column(
            children: <Widget>[
              Expanded(
                child: SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: viewportConstraints.maxHeight,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Container(
                          height: 165,
                          child: Padding(
                            padding: const EdgeInsets.all(
                              8.0,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                verticalSizedBox(),
                                GestureDetector(
                                  onTap: () {
                                    navigateToUserLocation(context);
                                  },
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: <Widget>[
                                      Container(
                                        height: 20,
                                        width: 20,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          border:
                                              Border.all(color: Colors.orange),
                                        ),
                                        child: Center(
                                          child: Icon(
                                            Icons.fiber_manual_record,
                                            color: Colors.orange,
                                            size: 10,
                                          ),
                                        ),
                                      ),
                                      horizontalSizedBox(),
                                      Flexible(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              'Deliver Location',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .display2
                                                  .copyWith(
                                                    fontSize: 12,
                                                  ),
                                            ),
                                            verticalSizedBox(),
                                            Text(
                                              'Indeonesia International Institute for Life Science',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .display1,
                                            ),
                                          ],
                                        ),
                                      ),
                                      horizontalSizedBox(),
                                      Icon(Icons.more_vert),
                                    ],
                                  ),
                                ),
                                verticalSizedBoxTwenty(),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.grey[100],
                                    borderRadius: BorderRadius.circular(5.0),
                                    border: Border.all(
                                      color: Colors.grey[200],
                                    ),
                                  ),
                                  height: 40,
                                  width: MediaQuery.of(context).size.width,
                                  child: Center(
                                    child: TextField(
                                      onChanged: (value) {
                                        // filterSearchResults(value);
                                      },
                                      style: TextStyle(
                                        fontStyle: FontStyle.normal,
                                        color: Colors.black,
                                        fontSize: 16,
                                      ),
                                      decoration: InputDecoration(
                                        hintText:
                                            "Add notes to delivery location",
                                        border: InputBorder.none,
                                        hintStyle: TextStyle(
                                            fontSize: 16, color: Colors.grey),
                                        prefixIcon: IconButton(
                                          icon: Icon(
                                            Icons.note_add,
                                            color: Colors.black45,
                                          ),
                                          onPressed: () {},
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
//                                Card(
//                                  child: Row(
//                                    children: <Widget>[
//                                      Padding(
//                                        padding: const EdgeInsets.all(10.0),
//                                        child: Icon(Icons.search,
//                                            size: 21.0, color: Colors.grey),
//                                      ),
//                                      Expanded(
//                                        child: TextField(
//                                          style: TextStyle(
//                                              fontSize: 14.0,
//                                              color: Colors.black),
//                                          decoration: InputDecoration(
//                                            border: InputBorder.none,
//                                            hintText: S
//                                                .of(context)
//                                                .searchForYourLocation,
//                                            hintStyle: TextStyle(
//                                              fontSize: 15.0,
//                                              color: Colors.grey,
//                                            ),
//                                            prefixIcon: IconButton(
//                                              icon: Icon(
//                                                Icons.note_add,
//                                                color: Colors.black45,
//                                              ),
//                                              onPressed: () {},
//                                            ),
//                                          ),
//                                        ),
//                                      ),
//                                    ],
//                                  ),
//                                ),
                              ],
                            ),
                          ),
                        ),
                        VerticalColoredSizedBox(),
                        Container(
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              children: <Widget>[
                                verticalSizedBox(),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Text(
                                      "Order item(s)",
                                      style:
                                          Theme.of(context).textTheme.display1,
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        navigateToHome(context: context);
                                      },
                                      child: Text(
                                        S.of(context).addMore,
                                        style: Theme.of(context)
                                            .textTheme
                                            .display3
                                            .copyWith(
                                              color: appColor,
                                            ),
                                      ),
                                    ),
                                  ],
                                ),
                                verticalSizedBox(),
                                divider(),
                                verticalSizedBoxFive(),
                                ListView.separated(
                                  separatorBuilder: (context, index) => Divider(
                                    color: Colors.grey[200],
                                  ),
                                  shrinkWrap: true,
                                  itemCount: 3,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 8.0,
                                      ),
                                      child: RestaurantItem(
                                          itemInfo: restaurantItemInfo,
                                          index: index),
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                        VerticalColoredSizedBox(),
                        cashOrWalletRow(),
                        VerticalColoredSizedBox(),
                        paymentDetailsColumn(),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: Column(
                  children: <Widget>[
                    verticalSizedBox(),
                    Row(
                      children: <Widget>[
                        horizontalSizedBox(),
                        Text('25,000',
                            style: Theme.of(context).textTheme.display3),
                        horizontalSizedBox(),
                        GestureDetector(
                          onTap: () {
                            openBottomSheet(context, SelectPaymentScreen());
                          },
                          child: Container(
                            height: 30,
                            width: 50,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20.0),
                              color: appColor,
                            ),
                            child: Center(
                              child: Text(
                                S.of(context).cash,
                                style: Theme.of(context)
                                    .textTheme
                                    .display2
                                    .copyWith(
                                      color: white,
                                    ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        child: FlatButton(
                          color: appColor,
                          child: Text(
                            S.of(context).order,
                            style:
                                Theme.of(context).textTheme.display1.copyWith(
                                      color: Colors.white,
                                    ),
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                            Navigator.of(context).pushNamed(
                              successOrder,
                            );
                          },
                        ),
                      ),
                    ),
                    RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: S.of(context).yayYouSaved,
                            style: Theme.of(context).textTheme.display2,
                          ),
                          TextSpan(
                            text: " 6.000 ",
                            style:
                                Theme.of(context).textTheme.display2.copyWith(
                                      color: blue,
                                    ),
                          ),
                          TextSpan(
                            text: S.of(context).onThisOrder,
                            style: Theme.of(context).textTheme.display2,
                          ),
                        ],
                      ),
                    ),
                    verticalSizedBox(),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  GestureDetector cashOrWalletRow() => GestureDetector(
        onTap: () {
          openBottomSheet(
            context,
            SelectPaymentScreen(),
            scrollControlled: false,
          );
        },
        child: Container(
          height: 50,
          child: Center(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    horizontalSizedBox(),
                    Icon(
                      Icons.note_add,
                      color: appColor,
                      size: 25.0,
                    ),
                    horizontalSizedBox(),
                    Text(
                      S.of(context).cash,
                      style: Theme.of(context).textTheme.display1,
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      S.of(context).delivery,
                      style: Theme.of(context).textTheme.display1,
                    ),
                    horizontalSizedBox(),
                    Text(
                      "6,000",
                      style: Theme.of(context).textTheme.display1,
                    ),
                    horizontalSizedBox(),
                    Icon(
                      Icons.more_vert,
                      size: 20.0,
                    ),
                    horizontalSizedBox(),
                  ],
                ),
              ],
            ),
          ),
        ),
      );

  Container paymentDetailsColumn() => Container(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: <Widget>[
              verticalSizedBox(),
              paymentDetailRow(
                textValueOne: S.of(context).paymentDetails,
                styleOne: Theme.of(context).textTheme.display3,
                textValueTwo: S.of(context).moreInfo,
                styleTwo: Theme.of(context).textTheme.display3.copyWith(
                      color: appColor,
                    ),
                onPressedTextTwo: () {
                  openBottomSheet(context, PaymentDetailScreen(),
                      scrollControlled: true);
                },
              ),
              verticalSizedBox(),
              divider(),
              verticalSizedBox(),
              paymentDetailRow(
                showSubTextOne: false,
                textValueOne: S.of(context).priceEstimated,
                styleOne: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 14,
                    ),
//                                  styleOne: TextStyle(
//                                      fontSize: 14,
//                                      fontStyle: FontStyle.normal,
//                                      color: Colors.black),
                textValueTwo: '17.500',
                styleTwo: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 14,
                    ),
              ),
              verticalSizedBox(),
              paymentDetailRow(
                textValueOne: S.of(context).convenienceFee,
                styleOne: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 14,
                    ),
                textValueTwo: 'Free',
                styleTwo: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 14,
                    ),
              ),
              verticalSizedBox(),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    S.of(context).deliveryFee,
                    style: Theme.of(context).textTheme.display2.copyWith(
                          fontSize: 14,
                        ),
                  ),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: '( 15.000 - ',
                          style: Theme.of(context).textTheme.display2.copyWith(
                                fontSize: 14,
                              ),
                        ),
                        TextSpan(
                          text: "6.000 ) ",
                          style: Theme.of(context).textTheme.display2.copyWith(
                                fontSize: 15,
                                color: blue,
                              ),
                        ),
                        TextSpan(
                          text: '9.000',
                          style: Theme.of(context).textTheme.display2.copyWith(
                                fontSize: 15,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              verticalSizedBox(),
              divider(),
              verticalSizedBox(),
              paymentDetailRow(
                textValueOne: S.of(context).totalPayment,
                styleOne: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                textValueTwo: "25.000",
                styleTwo: Theme.of(context).textTheme.display2.copyWith(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
        ),
      );
}
