import 'package:flutter/material.dart';
import 'package:foodstar/src/core/models/sample_models/restaurant_item_model.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/routes/restaurant_details/add_dish_notes_bottom_sheet.dart';
import 'package:foodstar/src/ui/routes/restaurant_details/restaurant_item_detail_bottom_sheet.dart';
import 'package:foodstar/src/ui/shared/others.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';
import 'package:foodstar/src/utils/dialog_helper.dart';

class RestaurantItem extends StatefulWidget {
  final List<RestaurantItemModel> itemInfo;
  final int index;
  final bool addWithPlusIcon; // show plus icon or not with add text
  final String imageTag;

  RestaurantItem(
      {this.itemInfo, this.index, this.addWithPlusIcon = true, this.imageTag});

  @override
  _RestaurantItemState createState() => _RestaurantItemState();
}

class _RestaurantItemState extends State<RestaurantItem> {
  int favoriteIndex = 0;
  int cartItemCount;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    cartItemCount = 1;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Offstage(
            offstage: widget.itemInfo[widget.index].image == "" ? true : false,
            child: InkWell(
              onTap: () {
                DialogHelper.menuPopup(context);
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: Image.asset(
                  widget.itemInfo[widget.index].image,
                  height: 70.0,
                  width: 70.0,
                ),
              ),
            ),
          ),
          SizedBox(
            width: 12,
          ),
          Expanded(
            flex: 2,
            child: Column(
              children: <Widget>[
                Material(
                  color: transparent,
                  child: InkWell(
                    onTap: () {
                      openBottomSheet(
                          context, RestaurantItemDetailBottomSheetScreen(),
                          scrollControlled: true);
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 3.0),
                              child: Container(
                                height: 13,
                                width: 13,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(
                                    2.0,
                                  ),
                                  border: Border.all(
                                      color: widget.itemInfo[widget.index]
                                              .favoriteStatus
                                          ? red
                                          : Colors.green),
                                ),
                                child: Center(
                                  child: Icon(
                                    Icons.fiber_manual_record,
                                    color: widget.itemInfo[widget.index]
                                            .favoriteStatus
                                        ? red
                                        : Colors.green,
                                    size: 10,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 3,
                            ),
                            Flexible(
                              child: Text(widget.itemInfo[widget.index].title,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.display1),
                            ),
                            GestureDetector(
                              onTap: () {
                                setState(
                                  () {
                                    favoriteIndex = widget.index;
                                  },
                                );
                              },
                              child: Icon(
                                Icons.favorite,
                                color: widget.addWithPlusIcon
                                    ? favoriteIndex == widget.index
                                        ? Colors.red
                                        : Colors.grey[300]
                                    : Colors.red,
                              ),
                            ),
                          ],
                        ),
                        verticalSizedBoxFive(),
                        Visibility(
                          visible: widget
                                  .itemInfo[widget.index].description.isNotEmpty
                              ? true
                              : false,
                          child: Text(
                            widget.itemInfo[widget.index].description,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.display2,
                          ),
                        ),
                        verticalSizedBoxFive(),
                        Row(
                          children: <Widget>[
                            Text(
                              widget.itemInfo[widget.index].originalPrice,
                              style: Theme.of(context)
                                  .textTheme
                                  .display3
                                  .copyWith(fontWeight: FontWeight.w600),
                            ),
                            horizontalSizedBox(),
                            Text(
                              widget.itemInfo[widget.index].offerPrice,
                              style:
                                  Theme.of(context).textTheme.display2.copyWith(
                                        color: Colors.grey[400],
                                        decoration: TextDecoration.lineThrough,
                                      ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                verticalSizedBox(),
                widget.itemInfo[widget.index].showAddButton
                    ? addButton(widget.addWithPlusIcon)
                    : editButton(
                        widget.itemInfo[widget.index].favoriteStatus,
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Align addButton(bool addPlusIcon) => Align(
        alignment: Alignment.centerRight,
        child: addPlusIcon
            ? Container(
                height: 25,
                width: 70,
                decoration: BoxDecoration(
                  color: widget.itemInfo[widget.index].addButtonStatus
                      ? appColor
                      : Colors.grey[300],
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: Center(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Add',
                        style: Theme.of(context)
                            .textTheme
                            .display3
                            .copyWith(color: white, fontSize: 13),
                      ),
                      horizontalSizedBox(),
                      Icon(
                        Icons.add,
                        color: Colors.white,
                        size: 17,
                      ),
                    ],
                  ),
                ),
              )
            : Container(
                height: 30,
                width: 70,
                decoration: BoxDecoration(
                  color: appColor,
                  borderRadius: BorderRadius.circular(
                    5.0,
                  ),
                ),
                child: Center(
                  child: Text(
                    'Add',
                    style: Theme.of(context)
                        .textTheme
                        .display3
                        .copyWith(color: white),
                  ),
                ),
              ),
      );

  Row editButton(bool favoriteStatus) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          Flexible(
            child: GestureDetector(
              onTap: () {
                openBottomSheet(context, AddDishNotesScreen(),
                    scrollControlled: true);
              },
              child: Container(
                height: 33,
                width: 33,
                child: Card(
                  elevation: 2,
                  child: Icon(
                    favoriteStatus ? Icons.check_circle : Icons.edit,
                    color: appColor,
                    size: 17.0,
                  ),
                ),
              ),
            ),
          ),
          horizontalSizedBox(),
          Flexible(
            child: Card(
              elevation: 2,
              child: Container(
                height: 25,
                width: 70,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 1.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        horizontalSizedBoxFive(),
                        Flexible(
                          child: Material(
                            color: transparent,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  cartItemCount = cartItemCount != 0
                                      ? cartItemCount - 1
                                      : cartItemCount;
                                });
                              },
                              child: Icon(
                                Icons.remove,
                                color: appColor,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                        horizontalSizedBox(),
                        Text("$cartItemCount",
                            style: Theme.of(context)
                                .textTheme
                                .display3
                                .copyWith(
                                    fontWeight: FontWeight.w400, fontSize: 14)),
                        horizontalSizedBox(),
                        Flexible(
                          child: Material(
                            color: transparent,
                            child: InkWell(
                              onTap: () {
                                setState(() {
                                  cartItemCount = cartItemCount + 1;
                                });
                              },
                              child: Icon(
                                Icons.add,
                                color: appColor,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                        horizontalSizedBoxFive(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      );
}
