import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:foodstar/src/ui/res/colors.dart';

Row paymentDetailRow(
        {String textValueOne = "",
        TextStyle styleOne,
        bool showSubTextOne = false,
        String subTextValueOne = "",
        TextStyle styleSubTextOne,
        String textValueTwo = "",
        TextStyle styleTwo,
        Function onPressedTextTwo,
        Function onPressedTextOne}) =>
    Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Flexible(
          flex: 1,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                textValueOne,
                overflow: TextOverflow.ellipsis,
                style: styleOne,
              ),
              SizedBox(
                height: 5.0,
              ),
              Visibility(
                visible: showSubTextOne,
                child: Text(
                  subTextValueOne,
                  style: styleSubTextOne,
                ),
              ),
            ],
          ),
        ),
        Flexible(
          child: Material(
            color: transparent,
            child: InkWell(
              onTap: onPressedTextTwo,
              child: Text(
                textValueTwo,
                style: styleTwo,
              ),
            ),
          ),
        ),
      ],
    );

IconButton closeIconButton(BuildContext context) => IconButton(
      icon: Icon(
        Icons.close,
        size: 25,
      ),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

openBottomSheet(BuildContext context, Widget routeName,
        {bool scrollControlled = false}) =>
    showModalBottomSheet(
      builder: (context) => routeName,
      context: context,
      isScrollControlled: scrollControlled,
    );

Center dragIcon() => Center(
      child: Icon(Icons.drag_handle, color: Colors.grey),
    );
