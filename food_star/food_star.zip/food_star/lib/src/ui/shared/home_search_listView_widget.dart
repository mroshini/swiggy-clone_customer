import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/core/models/arguments_model/imag_hero_tag_info.dart';
import 'package:foodstar/src/core/models/sample_models/home_model_data.dart';
import 'package:foodstar/src/ui/res/colors.dart';
import 'package:foodstar/src/ui/shared/shop_closed_widget.dart';
import 'package:foodstar/src/ui/shared/sizedbox.dart';

class FoodItems extends StatefulWidget {
  final int index;
  final String imageTag;

  FoodItems({this.index, this.imageTag});

  @override
  _FoodItemsState createState() => _FoodItemsState();
}

class _FoodItemsState extends State<FoodItems> {
  var homeInfo = HomeModelData().homeInfo;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.of(context).pushNamed(
          restaurantDetails,
          arguments: ImageHeroTagInfo(
            "${widget.imageTag}${widget.index}",
            homeInfo[widget.index].image == " "
                ? 'assets/images/no_image.png'
                : homeInfo[widget.index].image,
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.all(7.0),
        child: Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(10.0),
                child: Hero(
                  tag: "${widget.imageTag}${widget.index}",
                  child: Image.asset(
                    homeInfo[widget.index].image == " "
                        ? 'assets/images/no_image.png'
                        : homeInfo[widget.index].image,
                    height: 80.0,
                    width: 80.0,
                  ),
                ),
              ),
              SizedBox(
                width: 15,
                height: 10,
              ),
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      homeInfo[widget.index].lineOne,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context)
                          .textTheme
                          .display1
                          .copyWith(fontSize: 14, fontWeight: FontWeight.w600),
                    ),
//                    Row(
//                      children: <Widget>[
//                        Container(
//                          height: 13,
//                          width: 13,
//                          decoration: BoxDecoration(
//                            borderRadius: BorderRadius.circular(
//                              2.0,
//                            ),
//                            border: Border.all(
//                                color: homeInfo[widget.index].shopStatus == 1
//                                    ? red
//                                    : Colors.green),
//                          ),
//                          child: Center(
//                            child: Icon(
//                              Icons.fiber_manual_record,
//                              color: homeInfo[widget.index].shopStatus == 1
//                                  ? red
//                                  : Colors.green,
//                              size: 10,
//                            ),
//                          ),
//                        ),
//                        horizontalSizedBoxFive(),
//                        Flexible(
//                          child: Text(
//                            homeInfo[widget.index].lineOne,
//                            overflow: TextOverflow.ellipsis,
//                            style: Theme.of(context)
//                                .textTheme
//                                .display1
//                                .copyWith(
//                                    fontSize: 14,
//                                    fontWeight: FontWeight.w600),
//                          ),
//                        ),
//                      ],
//                    ),
                    verticalSizedBoxFive(),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          homeInfo[widget.index].lineTwo,
                          style: Theme.of(context).textTheme.display2.copyWith(
                                fontSize: 13,
                              ),
                        ),
                        Text(
                          ' - ',
                          style: Theme.of(context).textTheme.display3.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                        RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: r"$",
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                        fontSize: 11, color: Colors.black45),
                              ),
                              TextSpan(
                                text: r"$",
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                      color:
                                          (homeInfo[widget.index].shopStatus ==
                                                  1)
                                              ? Colors.black45
                                              : Colors.grey,
                                      fontSize: 11,
                                    ),
                              ),
                              TextSpan(
                                text: r"$",
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                        color: (homeInfo[widget.index]
                                                    .shopStatus ==
                                                1)
                                            ? Colors.black54
                                            : Colors.grey,
                                        fontSize: 11),
                              ),
                              TextSpan(
                                text: r"$",
                                style: Theme.of(context)
                                    .textTheme
                                    .display3
                                    .copyWith(
                                      color:
                                          (homeInfo[widget.index].shopStatus ==
                                                  1)
                                              ? Colors.grey[700]
                                              : Colors.grey,
                                      fontSize: 11,
                                    ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                    verticalSizedBoxFive(),
                    Row(
                      children: <Widget>[
                        Icon(
                          Icons.star,
                          color: (homeInfo[widget.index].shopStatus == 1)
                              ? Colors.amber
                              : Colors.grey[600],
                          size: 20.0,
                        ),
                        SizedBox(
                          width: 8,
                        ),
                        Text(
                          homeInfo[widget.index].rating,
                          style: Theme.of(context)
                              .textTheme
                              .display3
                              .copyWith(fontSize: 12),
                        ),
                        Text(
                          " - ",
                          style: Theme.of(context).textTheme.display3.copyWith(
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                        Text(
                          homeInfo[widget.index].distance,
                          style: Theme.of(context)
                              .textTheme
                              .display3
                              .copyWith(fontSize: 12),
                        ),
                        SizedBox(
                          width: 5,
                        ),
                        Text(
                          homeInfo[widget.index].timing ?? " ",
                          style: Theme.of(context)
                              .textTheme
                              .display2
                              .copyWith(fontSize: 12),
                        ),
                      ],
                    ),
                    Divider(
                      color: Colors.black45,
                    ),
                    SizedBox(
                      height: 3,
                    ),
                    (homeInfo[widget.index].shopStatus == 1)
                        ? shopOpenedWidget()
                        : (homeInfo[widget.index].shopStatus == 3)
                            ? showOutlets()
                            : shopClosedWidget(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Row shopOpenedWidget() => Row(
        children: <Widget>[
          Image.asset(
            "assets/images/percentage.jpg",
            width: 20,
            height: 20,
          ),
          SizedBox(
            width: 10,
          ),
          Text(
            'Promo',
            style: Theme.of(context).textTheme.display2.copyWith(fontSize: 13),
          ),
        ],
      );

  Row showOutlets() => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 18,
                width: 18,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.orange,
                  ),
                ),
                child: Center(
                  child: Icon(
                    Icons.fiber_manual_record,
                    color: Colors.orange,
                    size: 6,
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Text(
                'See more outlets',
                style: Theme.of(context).textTheme.display2.copyWith(
                      color: darkGreen,
                      fontSize: 13,
                    ),
              ),
            ],
          ),
          Flexible(
            child: GestureDetector(
              onTap: () {},
              child: Icon(
                Icons.keyboard_arrow_right,
                size: 20,
              ),
            ),
          ),
        ],
      );
}
