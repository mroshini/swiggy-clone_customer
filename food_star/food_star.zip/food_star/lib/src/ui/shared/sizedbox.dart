import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

SizedBox verticalSizedBox() => SizedBox(
      height: 10,
    );

SizedBox verticalSizedBoxTwenty() => SizedBox(
      height: 20,
    );

SizedBox horizontalSizedBox() => SizedBox(
      width: 10,
    );

SizedBox horizontalSizedBoxTwenty() => SizedBox(
      width: 20,
    );

Divider divider() => Divider(
      color: Colors.grey,
    );

SizedBox verticalSizedBoxFive() => SizedBox(
      height: 5,
    );

SizedBox horizontalSizedBoxFive() => SizedBox(
      width: 5,
    );
