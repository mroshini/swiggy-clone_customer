import 'package:flutter/material.dart';

Center showProgress(BuildContext context) =>
    Center(child: CircularProgressIndicator());
