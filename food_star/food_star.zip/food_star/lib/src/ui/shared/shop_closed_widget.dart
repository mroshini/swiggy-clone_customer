import 'package:flutter/material.dart';
import 'package:foodstar/src/ui/res/colors.dart';

RichText shopClosedWidget(BuildContext context) => RichText(
      text: TextSpan(
        children: [
          TextSpan(
            text: 'Closed',
            style: Theme.of(context).textTheme.display2.copyWith(
                color: darkRed, fontWeight: FontWeight.w600, fontSize: 13),
          ),
          TextSpan(
            text: "  ",
            style: TextStyle(
                fontSize: 16.0, fontWeight: FontWeight.w600, color: darkRed),
          ),
          TextSpan(
            text: 'Opens at 06.00 today',
            style: Theme.of(context).textTheme.display2.copyWith(
                  fontSize: 13,
                ),
          ),
        ],
      ),
    );
