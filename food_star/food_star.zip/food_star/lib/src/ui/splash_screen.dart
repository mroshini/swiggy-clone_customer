import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/route_path.dart';
import 'package:foodstar/src/constants/sharedpreference_keys.dart';
import 'package:foodstar/src/core/service/api_repository.dart';
import 'package:foodstar/src/utils/push_notification/push_notification_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  final String nxtScreen;

  SplashScreen({this.nxtScreen = login});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var clientId;
  SharedPreferences prefs;

  @override
  void initState() {
    super.initState();
    PushNotificationsManager().init();
    initialSetup();
  }

  initPref() async {
    if (prefs == null) prefs = await SharedPreferences.getInstance();
  }

  initialSetup() async {
    await initPref();

    clientId = prefs.getString(SharedPreferenceKeys.clientId) ?? "";

    if (clientId == "") {
      await ApiRepository(mContext: context).fetchAppEssentialCorerData();
    } else {}

    Future.delayed(
      Duration(seconds: 4),
      () {
        Navigator.of(context).pop();
        Navigator.pushNamed(context, widget.nxtScreen);
        // authProvider.setupInitialScreen();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: Center(
          child: Image.asset(
            'assets/images/splash_logo.png',
            width: 250,
            height: 250,
          ),
        ),
      ),
    );
  }
}
