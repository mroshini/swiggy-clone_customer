import 'package:flutter/material.dart';
import 'package:foodstar/src/ui/routes/restaurant_details/restaurant_menu_popup.dart';

class DialogHelper {
  static menuPopup(context) => showDialog(
      context: context, builder: (context) => RestaurantMenuPopUpScreen());

  static showErrorDialog(context) => showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Error'),
          content: Text('Error message'),
        );
      });

  static showProgressDialog(context) => showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(child: Center(child: CircularProgressIndicator()));
      });
}
