import 'package:flutter/material.dart';

class SearchRestaurantMenu extends SearchDelegate<String> {
  final restaurantMenu = [
    'French fries',
    'Special pizza',
    'Special pizza',
    'Special pizza',
    'Special pizza',
    'Special pizza',
    'Special pizza',
    'Special pizza',
    'Special pizza'
  ];

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.close),
        onPressed: () {
          query = "";
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {}

  @override
  Widget buildResults(BuildContext context) {
    return Text(query);
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggesionList =
        restaurantMenu.where((p) => p.startsWith(query)).toList();

    return ListView.separated(
      itemCount: suggesionList.length,
      itemBuilder: (context, index) {
        return Container(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  suggesionList[index],
                  style: Theme.of(context).textTheme.display3,
                ),
                Text(
                  '$index',
                  style: Theme.of(context).textTheme.display2,
                ),
              ],
            ),
          ),
        );
      },
      separatorBuilder: (BuildContext context, int index) {
        return Divider(
          color: Colors.grey[200],
        );
      },
    );
  }
}
