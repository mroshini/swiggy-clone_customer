import 'package:foodstar/src/constants/common_strings.dart';

String emailValidation(String value) {
  if (value.isEmpty) {
    return 'Please fill this field';
  } else if (!CommonStrings.emailRegEx.hasMatch(value)) {
    return "Please enter valid email address";
  } else {
    return null;
  }
}

String mobileNumberValidation(String value) {
  if (value.isEmpty) {
    return 'Please fill this field';
  } else if (!CommonStrings.mobileRegEx.hasMatch(value)) {
    return "Please enter valid number";
  } else {
    return null;
  }
}

String passwordValidation(String value) {
  if (value.isEmpty) {
    return 'Please fill this field';
  } else if (value.length < 6) {
    return "Password atleast contains 6 letters";
  } else {
    return null;
  }
}

String nameValidation(String value) {
  if (value.isEmpty) {
    return 'Please fill this field';
  } else {
    return null;
  }
}
