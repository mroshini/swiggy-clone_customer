import 'package:flushbar/flushbar.dart';
import 'package:flutter/material.dart';

void customSnackBar({BuildContext context, String title, String message}) {
  Flushbar(
    title: title,
    message: message,
    //flushbarPosition: FlushbarPosition.TOP,
    icon: Icon(
      Icons.info_outline,
      size: 28,
      color: Theme.of(context).primaryColor,
    ),
    leftBarIndicatorColor: Theme.of(context).accentColor,
    duration: Duration(seconds: 4),
  )..show(context);
}
