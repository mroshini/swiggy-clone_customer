import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/api_urls.dart';
import 'package:foodstar/src/constants/sharedpreference_keys.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<dynamic> myBackgroundMessageHandler(Map<String, dynamic> message) {
  if (message.containsKey('data')) {
    // Handle data message
    final dynamic data = message['data'];
    showLog('on background data $message');

    return data;
  }

  if (message.containsKey('notification')) {
    // Handle notification message
    final dynamic notification = message['notification'];
    showLog('on background data $message');

    return notification;
  }

  //return null;
  // Or do other work.
}

BuildContext _buildContext;

getBuildContext(BuildContext context) {
  _buildContext = context;
}

class FirebaseNotifications {
  FirebaseMessaging _firebaseMessaging;
  BuildContext _context;

  FirebaseNotifications(this._context);

  void setUpFirebase() {
    _firebaseMessaging = FirebaseMessaging();
    firebaseCloudMessagingListeners();
  }

  void firebaseCloudMessagingListeners() {
    if (Platform.isIOS) iOSPermission();

    _firebaseMessaging.getToken().then((token) {
      showLog('firebase token: $token');
    });

    _firebaseMessaging.onTokenRefresh.listen((token) async {
      showLog('firebase refreshed token: $token');

      var prefs = await SharedPreferences.getInstance();

      if (token != prefs.getString('${SharedPreferenceKeys.firebaseToken}') ??
          "") {
        showLog('inside firebase token refresh');
        prefs.setString('${SharedPreferenceKeys.firebaseToken}', token);

        //  _sendFirebaseTokenToServer(token);
      } else {
        showLog('inside firebase token refresh 2');
      }
    });

    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        showLog('on message $message');
        if (message.containsKey('data')) {
          final dynamic data = message['data'];
          showLog('on message data $message');
          // _sendNotificationSeenStatusToServer(data);
        }
      },
      // onBackgroundMessage: myBackgroundMessageHandler,
      onResume: (Map<String, dynamic> message) async {
        if (message.containsKey('data')) {
          final dynamic data = message['data'];
          showLog('on resume data $message');
          //   _sendNotificationSeenStatusToServer(data);
        }
      },
      onLaunch: (Map<String, dynamic> message) async {
        if (message.containsKey('data')) {
          final dynamic data = message['data'];
          showLog('on launch data $message');
          //  _sendNotificationSeenStatusToServer(data);
        }
      },
    );
  }

  void iOSPermission() {
    _firebaseMessaging.requestNotificationPermissions(
        IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
  }
}
