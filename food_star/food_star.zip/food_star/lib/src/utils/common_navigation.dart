import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodstar/src/constants/route_path.dart';

navigateToHome({BuildContext context, int menuType = 0}) {
  Navigator.of(context).pushNamedAndRemoveUntil(
      mainHome, (Route<dynamic> route) => false,
      arguments: menuType);
//  Navigator.pushNamed(
//    context,
//    mainHome,
//  );
}

navigateToUserLocation(BuildContext context) {
  Navigator.pushNamed(
    context,
    searchLocation,
    arguments: 3,
  );
}

void showAlertDialog({BuildContext context, String errorMessage}) {
  // flutter defined function

  showDialog(
    context: context,
    builder: (BuildContext context) {
      // return object of type Dialog

      return AlertDialog(
        title: new Text(
          errorMessage,
          style: Theme.of(context).textTheme.display1,
        ),
        actions: <Widget>[
          // usually buttons at the bottom of the dialog

          FlatButton(
            child: new Text("ok"),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ],
      );
    },
  );
}

void showInfoAlertDialog(
    {BuildContext context, String response, Function onClicked}) {
  // set up the button
  Widget okButton = FlatButton(
    child: Text(
      "OK",
      style: Theme.of(context).textTheme.display3,
    ),
    onPressed: () {
      onClicked(); //Navigator.of(context, rootNavigator: true).pop('alert');
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    shape: RoundedRectangleBorder(borderRadius: new BorderRadius.circular(15)),
    title: Text(
      response,
      style: Theme.of(context).textTheme.display1,
    ),
    actions: [
      okButton,
    ],
  );

  // show the dialog
  showDialog(
    barrierDismissible: false,
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
